# Jurnalistika — Elektron glossariy

Jurnalistika yo'nalishida tahsil olayotgan talabalar, o'qituvchilar va ommaviy axborot vositalariga qiziquvchilar uchun yaratilgan interaktiv ta'limiy veb-ilova. Ilova jurnalistikaga oid **30 ta o'zbekcha terminni** va ularning to'liq ta'riflarini o'rganish, bilimni test orqali mustahkamlash, o'z terminlar bazasini boshqarish va o'zlashtirish jarayonini kuzatish imkonini beradi.

**Barcha interfeys, terminlar, ta'riflar va test savollari o'zbek tilida, lotin yozuvida.**

## Texnologiyalar

- HTML5, CSS3, JavaScript (ES6+) — qo'shimcha kutubxona, framework yoki server talab qilinmaydi.
- Ma'lumotlar brauzerning **LocalStorage** xotirasida saqlanadi.
- Ovozli tinglash: brauzerning SpeechSynthesis API xizmati.

## Fayllar tuzilishi

```
jurnalistika-glossariy/
├── index.html            — barcha bo'limlar (bosh sahifa, glossariy, kartochkalar,
│                            testlar, natijalar, loyiha haqida, boshqaruv paneli)
├── styles.css            — 8 ta dizayn mavzusi, ko'p qatlamli jonli orqa fon,
│                            animatsiyalar, responsiv va chop etish uslublari
├── data.js               — 30 ta termin (ta'rif, qisqa ta'rif, qo'shimcha izoh,
│                            misol, kategoriya) va 30 ta test savoli
├── admin.js              — boshqaruv paneli: terminlarni qo'shish/tahrirlash/
│                            yashirish/o'chirish, JSON zaxira va import
├── app.js                — navigatsiya, qidiruv, kartochkalar, testlar,
│                            statistika, LocalStorage, CSV eksport
├── assets/
│   └── favicon.svg       — sayt belgisi
└── README.md
```

## Kompyuterda ishga tushirish

1-usul (eng oddiy): `index.html` faylini brauzerda oching (ikki marta bosing).

2-usul (tavsiya etiladi — mahalliy server):

```bash
# Python bilan
python3 -m http.server 8080
# yoki Node.js bilan
npx serve .
```

So'ng brauzerda `http://localhost:8080` manzilini oching.

## Imkoniyatlar

- **Elektron glossariy** — 30 ta o'zbekcha atama: to'liq ta'rif, qo'shimcha izoh (o'xshash atamalardan farqi) va amaliy misol bilan.
- **Qidiruv** — atama, ta'rif va izohlar bo'yicha, katta-kichik harflarni farqlamasdan, real vaqtda.
- **Filtrlar** — 4 ta kategoriya hamda o'rganilgan / o'rganilmagan / sevimli terminlar.
- **Saralash** — standart tartib, alifbo bo'yicha A–Z / Z–A, avval o'rganilmaganlar yoki o'rganilganlar.
- **O'rganish kartochkalari** — aylanadigan kartochkalar: old tomonda atama, orqa tomonda ta'rif. "Bilaman" / "Qayta takrorlash" belgilari, aralashtirish, takrorlash ro'yxati va klaviatura boshqaruvi (← / → / Enter).
- **Bilimni sinash — 3 rejim**:
  1. *Ta'rif bo'yicha topish* — ta'rif beriladi, mos atama tanlanadi (savollar banki: 30 ta asosiy savol + qo'shilgan terminlarga avtomatik tuzilgan savollar);
  2. *Ta'rifni tanlash* — atama beriladi, mos ta'rifi tanlanadi (barcha terminlardan avtomatik tuziladi);
  3. *Moslashtirish* — atamalarni ta'riflari bilan bosish orqali juftlash.
  Har bir javobdan keyin izoh chiqadi; yakunda to'g'ri/noto'g'ri javoblar soni, foiz va xato qilingan savollar ro'yxati ko'rsatiladi.
- **O'rganish natijalari** — o'rganish foizi, kategoriyalar bo'yicha progress, test tarixi, oxirgi va eng yaxshi natija — hammasi haqiqiy ma'lumotlar asosida va brauzerda saqlanadi.
- **8 ta dizayn mavzusi** — Klassik, Tungi ko'k, Gazeta, Neon Cyber, Pastel nafis, Foresta, Oltin tungi, Quyosh botishi. Sarlavhadagi palitra tugmasi orqali tanlanadi va brauzerda saqlanadi.
- **Ko'p qatlamli jonli orqa fon** — har bir mavzuda o'z atmosferasi: suzuvchi nur sharlari, setka, nuqtali matritsa, qog'oz donadorligi va vinyetka. Animatsiyalar faqat `transform` orqali, `prefers-reduced-motion` bilan o'chiriladi.
- **Boshqaruv paneli** — o'z terminlaringizni qo'shish (batafsil quyida).
- **CSV eksport** — UTF-8 (BOM) kodlashda, Excel bilan mos.
- **Chop etish** — glossariyni printer uchun toza formatda chiqarish.
- **Mobil moslashuv** — 360 px dan boshlab barcha ekranlar, gorizontal scroll yo'q.
- **Aksessuarlik** — semantik HTML, aria atributlari, klaviatura navigatsiyasi, fokus ko'rsatkichlari.

## Boshqaruv paneli — o'z terminlaringizni qo'shish

Navigatsiyadagi **Boshqaruv paneli** bo'limi orqali terminlar bazasini to'liq boshqarish mumkin:

- **Yangi termin qo'shish** — atama nomi, qisqa ta'rif, to'liq ta'rif, qo'shimcha izoh, misol va kategoriya kiritiladi. Saqlangandan keyin yangi termin **glossariy, qidiruv, filtrlar, kartochkalar, uch xil test, statistika, CSV eksport va kun terminida** darhol ishlaydi — standart terminlardan hech qanday farqi yo'q.
- **Tahrirlash** — standart terminlarni ham, o'zingiz qo'shganlarni ham tahrirlash mumkin. Tahrirlangan standart terminlar "Tahrirlangan" belgisi bilan ko'rinadi va bir tugma bilan asl holatiga qaytariladi.
- **Yashirish** — standart terminni vaqtincha ro'yxatlardan olib tashlash (keyin "Ko'rsatish" bilan qaytariladi).
- **O'chirish** — faqat o'zingiz qo'shgan terminlarni butunlay o'chirish.
- **JSON zaxira va import** — terminlarni faylga saqlash va boshqa qurilmada qayta yuklash (qo'shib yuklash yoki almashtirish rejimlarida).
- **Barcha o'zgarishlarni tiklash** — bazani asl holatiga qaytarish.

### Muhim cheklov (halol ma'lumot)

Boshqaruv paneli to'liq brauzer tomonida ishlaydi: **parol himoyasi yo'q** va qo'shilgan terminlar faqat shu brauzerda, shu qurilmada saqlanadi. Saytni bir necha kishi ishlatadigan bo'lsa, har birining qo'shilgan terminlari alohida saqlanadi. Ma'lumotlarni ko'chirish uchun JSON eksportdan foydalaning. Brauzer ma'lumotlarini tozalasangiz, qo'shilgan terminlar va o'rganish tarixi o'chadi.

## Internetga joylashtirish

Sayt faqat statik fayllardan iborat — har qanday statik hostingga mos keladi.

### GitHub Pages

1. GitHub'da yangi repozitoriya yarating (masalan, `jurnalistika-glossariy`).
2. Shu papkadagi barcha fayllarni (`index.html`, `styles.css`, `data.js`, `admin.js`, `app.js`, `assets/`) repozitoriaga yuklang:
   ```bash
   git init
   git add .
   git commit -m "Jurnalistika — elektron glossariy"
   git branch -M main
   git remote add origin https://github.com/SIZNING-KO'RSATKICHINGIZ/jurnalistika-glossariy.git
   git push -u origin main
   ```
3. Repozitoriyaning **Settings → Pages** bo'limiga o'ting.
4. "Source" sifatida `main` filialini (va ildiz `/ (root)`) tanlab, **Save** bosing.
5. Bir-ikki daqiqadan keyin sayt `https://foydalanuvchi-nomingiz.github.io/jurnalistika-glossariy/` manzilida ishlaydi.

### Vercel

1. [vercel.com](https://vercel.com) saytiga kiring (GitHub akkaunt bilan qulay).
2. "Add New → Project" tugmasini bosing va yuqoridagi repozitoriyani tanlang.
3. Sozlamalarni o'zgartirish shart emas — Vercel statik saytni avtomatik aniqlaydi.
4. "Deploy" tugmasini bosing. Bir daqiqadan keyin `https://loyiha-nomingiz.vercel.app` manzili tayyor.

**Eslatma:** yuqoridagi havolalar namuna sifatida yozilgan — haqiqiy manzil repozitoryaga va akkaunt nomingizga bog'liq bo'ladi. Havolani faqat o'zingiz joylashtirgandan keyin oling.

## Ma'lumot saqlanishi

Barcha o'rganish natijalari (`jgp_state_v1`), qo'shilgan terminlar (`jgp_custom_v1`), tahrirlar (`jgp_edits_v1`), yashirishlar (`jgp_hidden_v1`) va id ketma-ketligi (`jgp_seq_v1`) LocalStorage'da saqlanadi. Sayt serverga hech qanday ma'lumot yubormaydi va internet aloqasisiz ham to'liq ishlaydi.
