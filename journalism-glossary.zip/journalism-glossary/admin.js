/* ============================================================
   JOURNALISM GLOSSARY PRO — admin.js
   Boshqaruv paneli: terminlarni istalgancha qo'shish, tahrirlash,
   yashirish, o'chirish, JSON zaxira va import.

   Ishlash tartibi:
   - Standart 30 ta termin data.js da saqlanadi (o'zgarmas).
   - Foydalanuvchi qo'shgan terminlar, tahrirlar va yashirishlar
     LocalStorage'da saqlanadi (jgp_custom_v1, jgp_edits_v1,
     jgp_hidden_v1, jgp_seq_v1).
   - Bu fayl data.js dan keyin, app.js dan OLDIN yuklanadi —
     shu tufayli ilova ishga tushishidan oldin TERMS massivi
     standart + foydalanuvchi terminlari bilan birlashtiriladi.
     Natijada glossariy, kartochkalar, testlar va statistika
     admin qo'shgan terminlarni "o'zi bilan birga" ishlaydi.
   ============================================================ */
"use strict";

var AdminStore = (function () {
  var KEY_CUSTOM = "jgp_custom_v1";
  var KEY_EDITS = "jgp_edits_v1";
  var KEY_HIDDEN = "jgp_hidden_v1";
  var KEY_SEQ = "jgp_seq_v1";

  var storageOk = (function () {
    try {
      var t = "__jgp_admin_test__";
      window.localStorage.setItem(t, "1");
      window.localStorage.removeItem(t);
      return true;
    } catch (e) {
      return false;
    }
  })();

  /* data.js dagi asl (standart) terminlar — o'zgartirilmagan nusxa */
  var DEFAULT_TERMS = TERMS.slice();

  var custom = [];
  var edits = {};
  var hidden = [];
  var seq = 1000;

  /* ---------- LocalStorage yordamchilari ---------- */

  function readJson(key, fallback) {
    if (!storageOk) return fallback;
    try {
      var raw = window.localStorage.getItem(key);
      if (!raw) return fallback;
      var parsed = JSON.parse(raw);
      return parsed == null ? fallback : parsed;
    } catch (e) {
      console.warn("Admin: '" + key + "' o'qilmadi.", e);
      return fallback;
    }
  }

  function writeJson(key, value) {
    if (!storageOk) return;
    try {
      window.localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
      console.warn("Admin: '" + key + "' saqlanmadi.", e);
    }
  }

  /* ---------- Maydonlarni tozalash ---------- */

  function str(v, max) {
    return String(v == null ? "" : v).replace(/\s+/g, " ").trim().slice(0, max);
  }

  function validCat(c) {
    for (var i = 0; i < CATEGORIES.length; i++) {
      if (CATEGORIES[i].id === c) return c;
    }
    return "asos";
  }

  function cleanTerm(raw) {
    var c = {
      en: str(raw.en, 80),
      enDef: str(raw.enDef, 1200),
      uz: str(raw.uz, 140),
      uzShort: "",
      uzNote: str(raw.uzNote, 600),
      example: str(raw.example, 400),
      cat: validCat(raw.cat)
    };
    /* Qisqa ta'rif (moslashtirish testi uchun) — alohida kiritilmagan bo'lsa,
       qisqa ta'rif maydoni bilan bir xil saqlanadi */
    c.uzShort = str(raw.uzShort || c.uz, 140);
    return c;
  }

  /* Tahrir faqat ruxsat etilgan maydonlarni o'z ichiga olishi uchun */
  function cleanEdit(raw) {
    var c = cleanTerm(raw);
    delete c.cat; /* cat alohida qo'shiladi — faqat berilgan bo'lsa */
    var out = {};
    if (c.en) out.en = c.en;
    if (c.enDef) out.enDef = c.enDef;
    if (c.uz) out.uz = c.uz;
    if (c.uzShort) out.uzShort = c.uzShort;
    if (c.uzNote) out.uzNote = c.uzNote;
    if (c.example) out.example = c.example;
    var cat = validCat(raw.cat);
    out.cat = cat;
    return out;
  }

  function stripFlags(t) {
    var copy = Object.assign({}, t);
    delete copy._custom;
    return copy;
  }

  /* ---------- Ishga tushirish ---------- */

  function init() {
    var c = readJson(KEY_CUSTOM, []);
    custom = Array.isArray(c)
      ? c
          .filter(function (t) {
            return t && typeof t === "object" && String(t.en || "").trim() && String(t.uz || "").trim();
          })
          .map(function (t) {
            var clean = cleanTerm(t);
            clean.id = Number(t.id) || 0;
            clean._custom = true;
            return clean;
          })
      : [];

    var e = readJson(KEY_EDITS, {});
    edits = e && typeof e === "object" && !Array.isArray(e) ? e : {};

    var h = readJson(KEY_HIDDEN, []);
    hidden = Array.isArray(h)
      ? h
          .map(Number)
          .filter(function (n) {
            return defaultById(n);
          })
      : [];

    var sq = Number(readJson(KEY_SEQ, 0));
    seq = sq > 999 ? sq : 1000;
    custom.forEach(function (t) {
      if (t.id >= seq) seq = t.id + 1;
    });

    rebuild();
  }

  function nextId() {
    var id = seq;
    seq += 1;
    writeJson(KEY_SEQ, seq);
    return id;
  }

  /* ---------- TERMS massivini qayta yig'ish ---------- */

  function rebuild() {
    var list = [];
    DEFAULT_TERMS.forEach(function (t) {
      if (hidden.indexOf(t.id) !== -1) return;
      var e = edits[t.id];
      if (e) {
        var merged = Object.assign({}, t, e);
        merged.id = t.id;
        merged._custom = false;
        list.push(merged);
      } else {
        list.push(t);
      }
    });
    custom.forEach(function (t) {
      list.push(Object.assign({}, t));
    });
    /* TERMS — data.js dagi const massiv; xuddi shu referensni saqlab,
       ichini yangilaymiz. Shu tufayli app.js barcha joyida ishlayveradi. */
    TERMS.length = 0;
    for (var i = 0; i < list.length; i++) TERMS.push(list[i]);
  }

  function persist() {
    writeJson(KEY_CUSTOM, custom.map(stripFlags));
    writeJson(KEY_EDITS, edits);
    writeJson(KEY_HIDDEN, hidden);
  }

  /* ---------- Holat tekshiruvlari ---------- */

  function defaultById(id) {
    for (var i = 0; i < DEFAULT_TERMS.length; i++) {
      if (DEFAULT_TERMS[i].id === id) return DEFAULT_TERMS[i];
    }
    return null;
  }

  function isCustom(id) {
    for (var i = 0; i < custom.length; i++) {
      if (custom[i].id === id) return true;
    }
    return false;
  }

  function isHidden(id) {
    return hidden.indexOf(id) !== -1;
  }

  function isEdited(id) {
    return Object.prototype.hasOwnProperty.call(edits, String(id));
  }

  /* ---------- CRUD amallari ---------- */

  function add(data) {
    var t = cleanTerm(data);
    t.id = nextId();
    t._custom = true;
    custom.push(t);
    persist();
    rebuild();
    return t;
  }

  function update(id, data) {
    var clean = cleanTerm(data);
    var idx = -1;
    for (var i = 0; i < custom.length; i++) {
      if (custom[i].id === id) {
        idx = i;
        break;
      }
    }
    if (idx !== -1) {
      clean.id = id;
      clean._custom = true;
      custom[idx] = clean;
    } else if (defaultById(id)) {
      clean.id = id;
      edits[id] = clean;
    } else {
      return null;
    }
    persist();
    rebuild();
    return clean;
  }

  function removeCustom(id) {
    custom = custom.filter(function (t) {
      return t.id !== id;
    });
    persist();
    rebuild();
  }

  function hide(id) {
    if (!defaultById(id) || isHidden(id)) return;
    hidden.push(id);
    persist();
    rebuild();
  }

  function restore(id) {
    if (!isHidden(id)) return;
    hidden = hidden.filter(function (n) {
      return n !== id;
    });
    persist();
    rebuild();
  }

  function resetDefault(id) {
    if (!isEdited(id)) return;
    delete edits[id];
    persist();
    rebuild();
  }

  function resetAll() {
    custom = [];
    edits = {};
    hidden = [];
    persist();
    rebuild();
  }

  /* ---------- Import / eksport ---------- */

  function exportData() {
    return JSON.stringify(
      {
        app: "journalism-glossary",
        version: 1,
        exportedAt: new Date().toISOString(),
        counts: {
          total: TERMS.length,
          custom: custom.length,
          edited: Object.keys(edits).length,
          hidden: hidden.length
        },
        customTerms: custom.map(stripFlags),
        edits: edits,
        hidden: hidden
      },
      null,
      2
    );
  }

  /* Fayl matnini tekshirib, natijani qaytaradi (saqlamasdan) */
  function inspectImport(text) {
    var res = parseImport(text);
    if (!res.ok) return res;
    return { ok: true, count: res.items.length, skipped: res.skipped };
  }

  function parseImport(text) {
    var parsed;
    try {
      parsed = JSON.parse(text);
    } catch (e) {
      return { ok: false, error: "Fayl JSON formatida emas. Zaxira faylini yoki terminlar massivini yuklang." };
    }
    var arr = null;
    if (Array.isArray(parsed)) arr = parsed;
    else if (parsed && typeof parsed === "object" && Array.isArray(parsed.customTerms)) arr = parsed.customTerms;
    if (!arr) {
      return {
        ok: false,
        error: "Fayl tuzilmasi taniqmadi. Kutilgan shakl: { \"customTerms\": [...] } yoki to'g'ridan-to'g'ri terminlar massivi."
      };
    }
    var items = [];
    var skipped = 0;
    for (var i = 0; i < arr.length; i++) {
      var it = arr[i];
      if (!it || typeof it !== "object") {
        skipped++;
        continue;
      }
      var en = String(it.en == null ? "" : it.en).trim();
      var uz = String(it.uz == null ? "" : it.uz).trim();
      if (!en || !uz) {
        skipped++;
        continue;
      }
      var t = cleanTerm(it);
      if (!t.uzShort) t.uzShort = t.uz;
      items.push(t);
    }
    if (items.length === 0) {
      return {
        ok: false,
        error: "Faylda ishlatish mumkin bo'lgan termin topilmadi. Har bir yozuvda 'en' (atama nomi) va 'uz' (qisqa ta'rif) maydonlari bo'lishi shart."
      };
    }
    return { ok: true, items: items, skipped: skipped, parsed: parsed };
  }

  /* mode: "merge" (qo'shib) yoki "replace" (almashtirib) */
  function importData(text, mode) {
    var res = parseImport(text);
    if (!res.ok) return { ok: false, error: res.error };

    var added = 0;
    var dup = 0;
    var editsApplied = 0;
    var hiddenApplied = 0;

    if (mode === "replace") {
      custom = [];
      edits = {};
      hidden = [];
    }

    var existingEn = {};
    custom.forEach(function (t) {
      existingEn[String(t.en).toLowerCase()] = true;
    });
    DEFAULT_TERMS.forEach(function (t) {
      existingEn[String(t.en).toLowerCase()] = true;
    });

    res.items.forEach(function (t) {
      var key = String(t.en).toLowerCase();
      if (existingEn[key]) {
        dup++;
        return;
      }
      t.id = nextId();
      t._custom = true;
      custom.push(t);
      existingEn[key] = true;
      added++;
    });

    var p = res.parsed;
    if (p && typeof p === "object" && !Array.isArray(p)) {
      if (p.edits && typeof p.edits === "object" && !Array.isArray(p.edits)) {
        Object.keys(p.edits).forEach(function (k) {
          var id = Number(k);
          if (defaultById(id)) {
            edits[id] = cleanEdit(p.edits[k]);
            editsApplied++;
          }
        });
      }
      if (Array.isArray(p.hidden)) {
        p.hidden.forEach(function (hid) {
          var id = Number(hid);
          if (defaultById(id) && hidden.indexOf(id) === -1) {
            hidden.push(id);
            hiddenApplied++;
          }
        });
      }
    }

    persist();
    rebuild();

    var msg = added + " ta termin yuklandi";
    if (dup) msg += ", " + dup + " ta takroriy nom o'tkazib yuborildi";
    if (mode === "merge" && editsApplied) msg += ", " + editsApplied + " ta tahrir qo'llanildi";
    if (mode === "merge" && hiddenApplied) msg += ", " + hiddenApplied + " ta yashirish qo'llanildi";
    msg += ".";
    return { ok: true, message: msg };
  }

  /* ---------- Ommaviy API ---------- */

  return {
    init: init,
    rebuild: rebuild,
    isCustom: isCustom,
    isHidden: isHidden,
    isEdited: isEdited,
    defaultById: defaultById,
    hiddenIds: function () {
      return hidden.slice();
    },
    counts: function () {
      return {
        total: TERMS.length,
        custom: custom.length,
        edited: Object.keys(edits).length,
        hidden: hidden.length,
        defaults: DEFAULT_TERMS.length
      };
    },
    add: add,
    update: update,
    removeCustom: removeCustom,
    hide: hide,
    restore: restore,
    resetDefault: resetDefault,
    resetAll: resetAll,
    exportData: exportData,
    inspectImport: inspectImport,
    importData: importData,
    storageOk: function () {
      return storageOk;
    }
  };
})();

/* Standart + foydalanuvchi terminlarini birlashtirish —
   app.js yuklanishidan oldin bajarilishi shu fayl tartibi bilan kafolatlanadi */
AdminStore.init();

/* ============================================================
   ADMIN PANEL — interfeys
   ============================================================ */

var adminUi = { search: "", cat: "all", status: "all" };

var STATUS_META = {
  default: { label: "Standart", cls: "badge-default" },
  custom: { label: "Qo'shilgan", cls: "badge-custom" },
  edited: { label: "Tahrirlangan", cls: "badge-edited" },
  hidden: { label: "Yashirilgan", cls: "badge-hidden" }
};

function adminStatusOf(term) {
  if (AdminStore.isHidden(term.id)) return "hidden";
  if (AdminStore.isCustom(term.id)) return "custom";
  if (AdminStore.isEdited(term.id)) return "edited";
  return "default";
}

/* ---------- O'zgarishdan keyin butun ilovani yangilash ---------- */

function afterAdminChange(message) {
  if (typeof sanitizeTermState === "function") sanitizeTermState();
  if (typeof refreshAllViews === "function") refreshAllViews();
  renderAdminSection();
  if (typeof toast === "function" && message) toast(message);
}

/* ---------- Tugma yordamchisi ---------- */

function adminBtn(label, cls, action, id) {
  var b = el("button", "btn " + cls + " btn-sm");
  b.type = "button";
  b.setAttribute("data-action", action);
  b.setAttribute("data-id", String(id));
  b.textContent = label;
  return b;
}

/* ---------- Admin ro'yxati ---------- */

function buildAdminRow(term, status) {
  var row = el("article", "admin-row" + (status === "hidden" ? " is-hidden-row" : ""));
  row.setAttribute("data-id", String(term.id));

  row.appendChild(el("span", "admin-id", term._custom ? "+" : String(term.id)));

  var main = el("div", "admin-row-main");
  main.appendChild(el("p", "admin-term-name", term.en + " — " + term.uz));

  var badges = el("div", "admin-badges");
  var meta = STATUS_META[status] || STATUS_META.default;
  badges.appendChild(el("span", "badge " + meta.cls, meta.label));
  badges.appendChild(el("span", "badge badge-cat", categoryName(term.cat)));
  if (status === "custom" && !term.uzShort) badges.appendChild(el("span", "badge badge-edited", "Qisqa izoh yo'q"));
  main.appendChild(badges);
  row.appendChild(main);

  var actions = el("div", "admin-actions");
  if (status === "hidden") {
    actions.appendChild(adminBtn("Ko'rsatish", "btn-success", "restore", term.id));
  } else {
    actions.appendChild(adminBtn("Tahrirlash", "btn-outline", "edit", term.id));
    if (status === "edited") {
      actions.appendChild(adminBtn("Standartga qaytarish", "btn-ghost", "reset", term.id));
    }
    if (status === "custom") {
      actions.appendChild(adminBtn("O'chirish", "btn-danger-outline", "delete", term.id));
    } else {
      actions.appendChild(adminBtn("Yashirish", "btn-warn", "hide", term.id));
    }
  }
  row.appendChild(actions);
  return row;
}

function renderAdminList() {
  var listEl = $("#adminList");
  var emptyEl = $("#adminEmpty");
  var infoEl = $("#adminListInfo");
  if (!listEl || !emptyEl) return;

  var q = typeof normalize === "function" ? normalize(adminUi.search) : adminUi.search.toLowerCase();

  var rows = [];
  for (var i = 0; i < TERMS.length; i++) {
    rows.push({ term: TERMS[i], status: adminStatusOf(TERMS[i]) });
  }
  AdminStore.hiddenIds().forEach(function (hid) {
    var t = AdminStore.defaultById(hid);
    if (t) rows.push({ term: t, status: "hidden" });
  });

  rows = rows.filter(function (r) {
    if (q) {
      var en = String(r.term.en).toLowerCase();
      var uz = String(r.term.uz).toLowerCase();
      if (en.indexOf(q) === -1 && uz.indexOf(q) === -1) return false;
    }
    if (adminUi.cat !== "all" && r.term.cat !== adminUi.cat) return false;
    if (adminUi.status !== "all" && r.status !== adminUi.status) return false;
    return true;
  });

  rows.sort(function (a, b) {
    return a.term.id - b.term.id;
  });

  listEl.textContent = "";
  var frag = document.createDocumentFragment();
  rows.forEach(function (r) {
    frag.appendChild(buildAdminRow(r.term, r.status));
  });
  listEl.appendChild(frag);

  emptyEl.hidden = rows.length !== 0;
  if (infoEl) {
    infoEl.textContent = rows.length + " ta ko'rsatilgan (jami " + (TERMS.length + AdminStore.hiddenIds().length) + " ta yozuv)";
  }
}

function renderAdminChips() {
  var c = AdminStore.counts();
  var total = $("#adminTotal");
  var cust = $("#adminCustomCount");
  var edit = $("#adminEditedCount");
  var hid = $("#adminHiddenCount");
  if (total) total.textContent = String(c.total);
  if (cust) cust.textContent = String(c.custom);
  if (edit) edit.textContent = String(c.edited);
  if (hid) hid.textContent = String(c.hidden);
}

function renderAdminSection() {
  renderAdminChips();
  renderAdminList();
}

/* ---------- Umumiy tasdiq oynasi (Promise qaytaradi) ---------- */

var uiConfirmState = { resolve: null, lastFocus: null };

function uiConfirm(title, text, buttons) {
  return new Promise(function (resolve) {
    var overlay = $("#uiConfirmOverlay");
    if (!overlay) {
      resolve(window.confirm(text) ? true : null);
      return;
    }
    uiConfirmState.resolve = resolve;
    uiConfirmState.lastFocus = document.activeElement;
    $("#uiConfirmTitle").textContent = title;
    $("#uiConfirmText").textContent = text;

    var box = $("#uiConfirmActions");
    box.textContent = "";
    buttons.forEach(function (b) {
      var btn = el("button", "btn " + (b.cls || "btn-outline"));
      btn.type = "button";
      btn.textContent = b.label;
      btn.addEventListener("click", function () {
        finishUiConfirm(b.value);
      });
      box.appendChild(btn);
    });

    overlay.hidden = false;
    var first = box.querySelector("button");
    if (first) first.focus();
  });
}

function finishUiConfirm(value) {
  var overlay = $("#uiConfirmOverlay");
  if (overlay) overlay.hidden = true;
  var resolve = uiConfirmState.resolve;
  uiConfirmState.resolve = null;
  if (uiConfirmState.lastFocus && uiConfirmState.lastFocus.focus) uiConfirmState.lastFocus.focus();
  if (resolve) resolve(value);
}

/* ---------- Qo'shish / tahrirlash formasi ---------- */

var adminForm = { editingId: null, lastFocus: null };

function openAdminForm(id) {
  var overlay = $("#adminModal");
  if (!overlay) return;
  adminForm.editingId = typeof id === "number" ? id : null;
  adminForm.lastFocus = document.activeElement;

  var term = adminForm.editingId != null ? termById(adminForm.editingId) : null;
  if (adminForm.editingId != null && !term) {
    toast("Termin topilmadi.");
    return;
  }

  $("#adminModalTitle").textContent = adminForm.editingId != null ? "Terminni tahrirlash" : "Yangi termin qo'shish";
  $("#adminModalSub").textContent =
    adminForm.editingId != null
      ? "O'zgarishlar glossariy, kartochkalar, testlar va statistikada darhol ko'rinadi."
      : "Saqlangandan keyin yangi termin barcha bo'limlarda darhol ishlaydi.";

  $("#afEn").value = term ? term.en : "";
  $("#afEnDef").value = term ? term.enDef || "" : "";
  $("#afUz").value = term ? term.uz : "";
  $("#afUzNote").value = term ? term.uzNote || "" : "";
  $("#afExample").value = term ? term.example || "" : "";
  $("#afCat").value = term ? term.cat : "asos";

  var err = $("#adminFormError");
  err.hidden = true;
  err.textContent = "";

  var submit = $("#adminForm").querySelector('button[type="submit"]');
  if (submit) submit.textContent = adminForm.editingId != null ? "O'zgarishlarni saqlash" : "Qo'shish";

  overlay.hidden = false;
  $("#afEn").focus();
}

function closeAdminForm() {
  var overlay = $("#adminModal");
  if (overlay) overlay.hidden = true;
  adminForm.editingId = null;
  if (adminForm.lastFocus && adminForm.lastFocus.focus) adminForm.lastFocus.focus();
}

function validateAdminForm(data) {
  var errors = [];
  if (!data.en) errors.push("Termin nomi (atama) kiritilishi shart.");
  if (!data.uz) errors.push("Qisqa ta'rif kiritilishi shart (moslashtirish testida ishlatiladi).");
  if (!data.enDef) errors.push("To'liq ta'rif kiritilishi shart.");
  if (data.en && enExistsInTerms(data.en, adminForm.editingId)) {
    errors.push("Bu atama allaqachon mavjud — takroriy nom kiritish mumkin emas.");
  }
  return errors;
}

function enExistsInTerms(en, exceptId) {
  var q = typeof normalize === "function" ? normalize(en) : String(en).toLowerCase();
  for (var i = 0; i < TERMS.length; i++) {
    if (exceptId != null && TERMS[i].id === exceptId) continue;
    var other = typeof normalize === "function" ? normalize(TERMS[i].en) : String(TERMS[i].en).toLowerCase();
    if (other === q) return true;
  }
  return false;
}

function showAdminFormError(message) {
  var err = $("#adminFormError");
  err.textContent = message;
  err.hidden = false;
}

function submitAdminForm(e) {
  e.preventDefault();
  var data = {
    en: $("#afEn").value,
    enDef: $("#afEnDef").value,
    uz: $("#afUz").value,
    uzNote: $("#afUzNote").value,
    example: $("#afExample").value,
    cat: $("#afCat").value
  };
  var errors = validateAdminForm(data);
  if (errors.length) {
    showAdminFormError(errors.join(" "));
    return;
  }
  if (adminForm.editingId != null) {
    AdminStore.update(adminForm.editingId, data);
    closeAdminForm();
    afterAdminChange("Termin tahrirlandi va barcha bo'limlar yangilandi.");
  } else {
    AdminStore.add(data);
    closeAdminForm();
    afterAdminChange("Yangi termin qo'shildi — endi u glossariy, kartochkalar va testlarda ishlaydi.");
  }
}

/* ---------- JSON eksport / import ---------- */

function downloadJson() {
  var blob = new Blob([AdminStore.exportData()], { type: "application/json;charset=utf-8" });
  var url = URL.createObjectURL(blob);
  var a = document.createElement("a");
  a.href = url;
  a.download = "jurnalistika-glossariy-zaxira.json";
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(function () {
    URL.revokeObjectURL(url);
  }, 1000);
  toast("Zaxira JSON fayli yuklab olindi.");
}

function handleImportFile(file) {
  if (!file) return;
  var reader = new FileReader();
  reader.onload = function () {
    var text = String(reader.result || "");
    var check = AdminStore.inspectImport(text);
    if (!check.ok) {
      toast(check.error);
      return;
    }
    uiConfirm(
      "JSON import",
      "Fayl " + check.count + " ta mos terminni o'z ichiga oladi. Qanday yuklash kerak?" +
        (check.skipped ? " (" + check.skipped + " ta yaroqsiz yozuv o'tkazib yuboriladi.)" : ""),
      [
        { label: "Bekor qilish", value: null, cls: "btn-outline" },
        { label: "Almashtirish", value: "replace", cls: "btn-danger" },
        { label: "Qo'shib yuklash", value: "merge", cls: "btn-primary" }
      ]
    ).then(function (mode) {
      if (!mode) return;
      var res = AdminStore.importData(text, mode);
      if (res.ok) afterAdminChange(res.message);
      else toast(res.error);
    });
  };
  reader.onerror = function () {
    toast("Faylni o'qish amalga oshmadi.");
  };
  reader.readAsText(file, "utf-8");
}

/* ---------- Admin bo'limini ishga tushirish ---------- */

function initAdmin() {
  /* Kategoriya filtri va forma selectlarini to'ldirish */
  var catFilter = $("#adminCatFilter");
  if (catFilter) {
    catFilter.appendChild(new Option("Barcha kategoriyalar", "all"));
    CATEGORIES.forEach(function (c) {
      catFilter.appendChild(new Option(c.name, c.id));
    });
    catFilter.addEventListener("change", function () {
      adminUi.cat = catFilter.value;
      renderAdminList();
    });
  }

  var catSel = $("#afCat");
  if (catSel) {
    CATEGORIES.forEach(function (c) {
      catSel.appendChild(new Option(c.name, c.id));
    });
  }

  var statusFilter = $("#adminStatusFilter");
  if (statusFilter) {
    statusFilter.addEventListener("change", function () {
      adminUi.status = statusFilter.value;
      renderAdminList();
    });
  }

  var search = $("#adminSearch");
  if (search) {
    var timer = null;
    search.addEventListener("input", function () {
      adminUi.search = search.value;
      if (timer) clearTimeout(timer);
      timer = window.setTimeout(renderAdminList, 130);
    });
  }

  var addBtn = $("#adminAdd");
  if (addBtn) addBtn.addEventListener("click", function () { openAdminForm(null); });

  var exportBtn = $("#adminExport");
  if (exportBtn) exportBtn.addEventListener("click", downloadJson);

  var importBtn = $("#adminImport");
  var fileInput = $("#adminImportFile");
  if (importBtn && fileInput) {
    importBtn.addEventListener("click", function () {
      fileInput.click();
    });
    fileInput.addEventListener("change", function () {
      var f = fileInput.files && fileInput.files[0];
      fileInput.value = "";
      handleImportFile(f);
    });
  }

  var resetBtn = $("#adminResetAll");
  if (resetBtn) {
    resetBtn.addEventListener("click", function () {
      var c = AdminStore.counts();
      uiConfirm(
        "Barcha o'zgarishlarni tiklash",
        c.custom + " ta qo'shilgan termin o'chiriladi, " + c.edited + " ta tahrir va " + c.hidden + " ta yashirish bekor qilinadi. Bu amalni qaytarib bo'lmaydi. Davom etasizmi?",
        [
          { label: "Bekor qilish", value: null, cls: "btn-outline" },
          { label: "Ha, tiklash", value: true, cls: "btn-danger" }
        ]
      ).then(function (v) {
        if (!v) return;
        AdminStore.resetAll();
        afterAdminChange("Barcha o'zgarishlar tiklandi — faqat standart terminlar qoldi.");
      });
    });
  }

  /* Ro'yxatdagi amallar (delegatsiya) */
  var list = $("#adminList");
  if (list) {
    list.addEventListener("click", function (e) {
      var btn = e.target.closest("[data-action]");
      if (!btn) return;
      var id = Number(btn.getAttribute("data-id"));
      var action = btn.getAttribute("data-action");
      var term = termById(id) || AdminStore.defaultById(id);
      if (!term) return;

      if (action === "edit") {
        openAdminForm(id);
      } else if (action === "hide") {
        uiConfirm(
          "Terminni yashirish",
          "«" + term.en + "» termini glossariy, kartochkalar va testlardan vaqtincha olib tashlanadi. Keyin «Ko'rsatish» tugmasi orqali qaytarish mumkin.",
          [
            { label: "Bekor qilish", value: null, cls: "btn-outline" },
            { label: "Yashirish", value: true, cls: "btn-warn" }
          ]
        ).then(function (v) {
          if (v) {
            AdminStore.hide(id);
            afterAdminChange("Termin yashirildi.");
          }
        });
      } else if (action === "restore") {
        AdminStore.restore(id);
        afterAdminChange("Termin qayta ko'rsatildi.");
      } else if (action === "delete") {
        uiConfirm(
          "Terminni o'chirish",
          "«" + term.en + "» termini butunlay o'chiriladi. Bu amalni qaytarib bo'lmaydi. Davom etasizmi?",
          [
            { label: "Bekor qilish", value: null, cls: "btn-outline" },
            { label: "Ha, o'chirish", value: true, cls: "btn-danger" }
          ]
        ).then(function (v) {
          if (v) {
            AdminStore.removeCustom(id);
            afterAdminChange("Termin o'chirildi.");
          }
        });
      } else if (action === "reset") {
        uiConfirm(
          "Standart holatga qaytarish",
          "«" + term.en + "» terminiga keltirilgan barcha tahrirlar bekor qilinadi va asl matn tiklanadi.",
          [
            { label: "Bekor qilish", value: null, cls: "btn-outline" },
            { label: "Qaytarish", value: true, cls: "btn-primary" }
          ]
        ).then(function (v) {
          if (v) {
            AdminStore.resetDefault(id);
            afterAdminChange("Termin standart holatiga qaytarildi.");
          }
        });
      }
    });
  }

  /* Forma modali */
  var form = $("#adminForm");
  if (form) form.addEventListener("submit", submitAdminForm);

  var modalClose = $("#adminModalClose");
  if (modalClose) modalClose.addEventListener("click", closeAdminForm);

  var modalCancel = $("#adminModalCancel");
  if (modalCancel) modalCancel.addEventListener("click", closeAdminForm);

  var adminOverlay = $("#adminModal");
  if (adminOverlay) {
    adminOverlay.addEventListener("click", function (e) {
      if (e.target === adminOverlay) closeAdminForm();
    });
    adminOverlay.addEventListener("keydown", function (e) {
      if (e.key === "Escape") {
        closeAdminForm();
        return;
      }
      trapFocus(e, adminOverlay);
    });
  }

  /* Tasdiq oynasi */
  var confirmOverlay = $("#uiConfirmOverlay");
  if (confirmOverlay) {
    confirmOverlay.addEventListener("click", function (e) {
      if (e.target === confirmOverlay) finishUiConfirm(null);
    });
    confirmOverlay.addEventListener("keydown", function (e) {
      if (e.key === "Escape") {
        finishUiConfirm(null);
        return;
      }
      trapFocus(e, confirmOverlay);
    });
  }
}

/* Dialog ichida fokusni ushlab turish (Tab sikli) */
function trapFocus(e, overlay) {
  if (e.key !== "Tab") return;
  var focusables = overlay.querySelectorAll("button, input, textarea, select, a[href]");
  if (!focusables.length) return;
  var first = focusables[0];
  var last = focusables[focusables.length - 1];
  if (e.shiftKey && document.activeElement === first) {
    e.preventDefault();
    last.focus();
  } else if (!e.shiftKey && document.activeElement === last) {
    e.preventDefault();
    first.focus();
  }
}
