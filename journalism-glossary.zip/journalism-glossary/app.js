/* ============================================================
   JOURNALISM GLOSSARY PRO — app.js
   Vazifasi: barcha interaktiv funksiyalar — navigatsiya,
   qidiruv, filtr, saralash, flashcards, testlar, talaffuz,
   statistika, LocalStorage, CSV eksport, qorong'i rejim.
   ============================================================ */
"use strict";

/* ================= Yordamchi funksiyalar ================= */

function $(sel) {
  return document.querySelector(sel);
}

function $all(sel) {
  return Array.prototype.slice.call(document.querySelectorAll(sel));
}

/* Xavfsiz element yaratish (matn textContent orqali joylanadi) */
function el(tag, className, text) {
  var node = document.createElement(tag);
  if (className) node.className = className;
  if (typeof text === "string") node.textContent = text;
  return node;
}

/* Massivni aralashtirish (Fisher-Yates, aslini o'zgartirmaydi) */
function shuffle(arr) {
  var a = arr.slice();
  for (var i = a.length - 1; i > 0; i--) {
    var j = Math.floor(Math.random() * (i + 1));
    var tmp = a[i];
    a[i] = a[j];
    a[j] = tmp;
  }
  return a;
}

/* Qidiruv uchun matnni me'yorlashtirish: kichik harf + apostroflarni birlashtirish */
function normalize(s) {
  return String(s || "")
    .toLowerCase()
    .replace(/[\u2018\u2019\u02BB\u02BC`]/g, "'")
    .replace(/\s+/g, " ")
    .trim();
}

function termById(id) {
  for (var i = 0; i < TERMS.length; i++) {
    if (TERMS[i].id === id) return TERMS[i];
  }
  return null;
}

/* ================= Holat va LocalStorage ================= */

var STORAGE_KEY = "jgp_state_v1";

var storage = (function () {
  var ok = false;
  try {
    var t = "__jgp_test__";
    window.localStorage.setItem(t, "1");
    window.localStorage.removeItem(t);
    ok = true;
  } catch (e) {
    ok = false;
  }
  return { ok: ok };
})();

var DEFAULT_STATE = {
  version: 1,
  learned: [],
  repeat: [],
  favorites: [],
  quizzes: [],
  theme: null,
  design: null,
  scope: "all",
  lastActive: null
};

function loadState() {
  if (!storage.ok) return Object.assign({}, DEFAULT_STATE);
  try {
    var raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return Object.assign({}, DEFAULT_STATE);
    var parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== "object") return Object.assign({}, DEFAULT_STATE);
    var s = Object.assign({}, DEFAULT_STATE, parsed);
    s.learned = validIds(s.learned);
    s.repeat = validIds(s.repeat);
    s.favorites = validIds(s.favorites);
    s.quizzes = Array.isArray(s.quizzes) ? s.quizzes.slice(-100) : [];
    if (s.theme !== "light" && s.theme !== "dark") s.theme = null;
    /* DESIGN_IDS hali yuklanmagan bo'lishi mumkin — lokal ro'yxat bilan tekshiramiz */
    var known = ["klassik", "tungi", "gazeta", "neon", "pastel", "foresta", "oltin", "quyosh"];
    if (known.indexOf(s.design) === -1) s.design = null;
    if (s.scope !== "all" && s.scope !== "unlearned") s.scope = "all";
    return s;
  } catch (e) {
    console.warn("LocalStorage ma'lumotlari buzilgan, holat tiklandi.", e);
    return Object.assign({}, DEFAULT_STATE);
  }
}

function validIds(list) {
  if (!Array.isArray(list)) return [];
  var seen = {};
  var out = [];
  for (var i = 0; i < list.length; i++) {
    var n = Number(list[i]);
    if (termById(n) && !seen[n]) {
      seen[n] = true;
      out.push(n);
    }
  }
  return out;
}

var state = loadState();

function saveState() {
  state.lastActive = new Date().toISOString();
  if (!storage.ok) return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (e) {
    console.warn("Ma'lumotni saqlash amalga oshmadi.", e);
  }
}

function learnedCount() {
  return state.learned.length;
}

function isLearned(id) {
  return state.learned.indexOf(id) !== -1;
}

function isRepeat(id) {
  return state.repeat.indexOf(id) !== -1;
}

function isFav(id) {
  return state.favorites.indexOf(id) !== -1;
}

function markLearned(id, on) {
  removeFromArr(state.repeat, id);
  if (on) {
    if (!isLearned(id)) state.learned.push(id);
  } else {
    removeFromArr(state.learned, id);
  }
  saveState();
  refreshProgressUI();
}

function markRepeat(id, on) {
  removeFromArr(state.learned, id);
  if (on) {
    if (!isRepeat(id)) state.repeat.push(id);
  } else {
    removeFromArr(state.repeat, id);
  }
  saveState();
  refreshProgressUI();
}

function toggleFav(id) {
  if (isFav(id)) removeFromArr(state.favorites, id);
  else state.favorites.push(id);
  saveState();
}

function removeFromArr(arr, val) {
  var i = arr.indexOf(val);
  if (i !== -1) arr.splice(i, 1);
}

/* ================= Toast ================= */

var toastTimer = null;

function toast(message, ms) {
  var t = $("#toast");
  if (!t) return;
  t.textContent = message;
  t.hidden = false;
  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(function () {
    t.hidden = true;
  }, ms || 3200);
}

/* ================= Dizayn mavzulari (8 ta) ================= */

var DESIGNS = [
  { id: "klassik", name: "Klassik", desc: "Silliq ko'k akzentli zamonaviy yorug' dizayn", colors: ["#10243A", "#3478F6", "#F5F7FA"], meta: "#10243A" },
  { id: "tungi", name: "Tungi ko'k", desc: "Ochiq ko'k urg'ular bilan qulay qorong'i rejim", colors: ["#0A1420", "#5B94F8", "#13202F"], meta: "#0C1622" },
  { id: "gazeta", name: "Gazeta", desc: "Qog'oz muhrli vintage matbuot uslubi, serif shrift", colors: ["#241C10", "#A02E20", "#F3ECDD"], meta: "#241C10" },
  { id: "neon", name: "Neon Cyber", desc: "Siyoh fon, neon-yashil va magenta porlash", colors: ["#05070C", "#00E5C7", "#FF4FD8"], meta: "#07090F" },
  { id: "pastel", name: "Pastel nafis", desc: "Yumshoq binafsha-pastel palitra, katta burchaklar", colors: ["#4A3B78", "#8A63E8", "#F07EB0"], meta: "#4A3B78" },
  { id: "foresta", name: "Foresta", desc: "Tinchlantiruvchi o'rmon-yashil ohanglar", colors: ["#17301F", "#2E7D57", "#67B58D"], meta: "#17301F" },
  { id: "oltin", name: "Oltin tungi", desc: "Premium qorong'i fon va oltin sarlavhalar", colors: ["#0E0C07", "#D4A64A", "#E8C97E"], meta: "#0E0C07" },
  { id: "quyosh", name: "Quyosh botishi", desc: "Iliq to'q sariq va pushti ohangdagi yorug' mavzu", colors: ["#3A1F14", "#E86A33", "#E94D7E"], meta: "#3A1F14" }
];

var DESIGN_IDS = DESIGNS.map(function (d) { return d.id; });

function applyDesign(id) {
  if (DESIGN_IDS.indexOf(id) === -1) id = "klassik";
  document.documentElement.setAttribute("data-design", id);
  var meta = document.querySelector('meta[name="theme-color"]');
  var conf = null;
  for (var i = 0; i < DESIGNS.length; i++) {
    if (DESIGNS[i].id === id) { conf = DESIGNS[i]; break; }
  }
  if (meta && conf) meta.setAttribute("content", conf.meta);
  syncDesignButtons();
}

function prefersDarkMode() {
  try {
    return !!(window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches);
  } catch (e) {
    return false;
  }
}

function prefersReducedMotion() {
  try {
    return !!(window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches);
  } catch (e) {
    return false;
  }
}

function initDesign() {
  var saved = state.design;
  /* Eski saqlangan yorug'/qorong'i rejimni mavzuga ko'chirish */
  if (!saved && state.theme === "dark") saved = "tungi";
  if (!saved && state.theme === "light") saved = "klassik";
  if (!saved) saved = prefersDarkMode() ? "tungi" : "klassik";
  applyDesign(saved);
}

function syncDesignButtons() {
  var cur = document.documentElement.getAttribute("data-design") || "klassik";
  $all(".design-option").forEach(function (btn) {
    var on = btn.getAttribute("data-design-id") === cur;
    btn.classList.toggle("is-active", on);
    btn.setAttribute("aria-pressed", on ? "true" : "false");
    var badge = btn.querySelector(".design-active-badge");
    if (badge) badge.hidden = !on;
  });
}

function buildDesignGrid() {
  var grid = $("#designGrid");
  if (!grid) return;
  grid.textContent = "";
  DESIGNS.forEach(function (d) {
    var btn = el("button", "design-option");
    btn.type = "button";
    btn.setAttribute("data-design-id", d.id);
    btn.setAttribute("aria-pressed", "false");
    var sw = el("span", "design-swatch");
    for (var i = 0; i < d.colors.length; i++) {
      var dot = el("i");
      dot.style.background = d.colors[i];
      sw.appendChild(dot);
    }
    btn.appendChild(sw);
    btn.appendChild(el("span", "design-name", d.name));
    btn.appendChild(el("span", "design-desc", d.desc));
    btn.appendChild(el("span", "design-active-badge", "Faol"));
    btn.addEventListener("click", function () {
      chooseDesign(d.id);
    });
    grid.appendChild(btn);
  });
  syncDesignButtons();
}

function chooseDesign(id) {
  var current = document.documentElement.getAttribute("data-design");
  if (current === id) { closeDesignPanel(); return; }
  state.design = id;
  state.theme = null;
  saveState();
  /* Mavzu almashganda ranglar qisqa vaqtga silliq o'tadi (optimallashtirilgan transition) */
  document.documentElement.classList.add("design-switching");
  window.setTimeout(function () {
    document.documentElement.classList.remove("design-switching");
  }, 340);
  if (document.startViewTransition && !prefersReducedMotion()) {
    try {
      document.startViewTransition(function () { applyDesign(id); });
    } catch (e) {
      applyDesign(id);
    }
  } else {
    applyDesign(id);
  }
  var conf = null;
  for (var i = 0; i < DESIGNS.length; i++) {
    if (DESIGNS[i].id === id) conf = DESIGNS[i];
  }
  toast("Dizayn mavzusi: " + (conf ? conf.name : id) + ".");
  closeDesignPanel();
}

var lastDesignTrigger = null;

function openDesignPanel() {
  var overlay = $("#designOverlay");
  var btn = $("#designBtn");
  if (!overlay) return;
  lastDesignTrigger = document.activeElement;
  overlay.hidden = false;
  if (btn) btn.setAttribute("aria-expanded", "true");
  var first = overlay.querySelector(".design-option");
  if (first) first.focus();
}

function closeDesignPanel() {
  var overlay = $("#designOverlay");
  var btn = $("#designBtn");
  if (!overlay || overlay.hidden) return;
  overlay.hidden = true;
  if (btn) btn.setAttribute("aria-expanded", "false");
  if (lastDesignTrigger && lastDesignTrigger.focus) lastDesignTrigger.focus();
}

function initDesignPanel() {
  buildDesignGrid();
  var openBtn = $("#designBtn");
  if (openBtn) openBtn.addEventListener("click", openDesignPanel);
  var closeBtn = $("#designClose");
  if (closeBtn) closeBtn.addEventListener("click", closeDesignPanel);
  var overlay = $("#designOverlay");
  if (overlay) {
    overlay.addEventListener("click", function (e) {
      if (e.target === overlay) closeDesignPanel();
    });
    overlay.addEventListener("keydown", function (e) {
      if (e.key === "Escape") {
        closeDesignPanel();
        return;
      }
      if (e.key === "Tab") {
        var focusables = overlay.querySelectorAll(".design-option, #designClose");
        if (!focusables.length) return;
        var first = focusables[0];
        var last = focusables[focusables.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    });
  }
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") closeDesignPanel();
  });
}

/* ================= Talaffuz (SpeechSynthesis) ================= */

var speech = { voices: [], uzVoice: null, ready: false };

function pickVoice() {
  if (!("speechSynthesis" in window)) return;
  speech.voices = window.speechSynthesis.getVoices() || [];
  speech.uzVoice = null;
  for (var i = 0; i < speech.voices.length; i++) {
    var v = speech.voices[i];
    if (/^uz(-|_|$)/i.test(v.lang)) {
      speech.uzVoice = v;
      break;
    }
  }
  speech.ready = true;
}

function initSpeech() {
  if (!("speechSynthesis" in window)) return;
  pickVoice();
  window.speechSynthesis.onvoiceschanged = pickVoice;
}

var isSpeaking = false;

function speak(text) {
  if (!("speechSynthesis" in window)) {
    toast("Kechirasiz, brauzeringiz ovozli talaffuzni qo'llab-quvvatlamaydi.");
    return;
  }
  try {
    window.speechSynthesis.cancel();
    var u = new window.SpeechSynthesisUtterance(text);
    if (!speech.ready) pickVoice();
    u.lang = speech.uzVoice ? speech.uzVoice.lang : "uz-UZ";
    if (speech.uzVoice) u.voice = speech.uzVoice;
    u.rate = 0.95;
    u.pitch = 1;
    u.onstart = function () {
      isSpeaking = true;
    };
    u.onend = function () {
      isSpeaking = false;
    };
    u.onerror = function () {
      isSpeaking = false;
      toast("Ovozni ijra etishda muammo bo'ldi. O'zbekcha ovoz qurilmangizda o'rnatilmagan bo'lishi mumkin.");
    };
    window.speechSynthesis.speak(u);
  } catch (e) {
    isSpeaking = false;
    toast("Tinglash funksiyasi ishlamadi. Boshqa brauzerda urinib ko'ring.");
  }
}

/* ================= Router (bo'limlar orasida ko'chish) ================= */

var VIEWS = ["home", "glossary", "flashcards", "quiz", "stats", "about", "admin"];
var currentView = "home";

function viewFromHash() {
  var h = (window.location.hash || "").replace("#", "");
  return VIEWS.indexOf(h) !== -1 ? h : "home";
}

function showView(name) {
  currentView = name;
  for (var i = 0; i < VIEWS.length; i++) {
    var sec = document.getElementById(VIEWS[i]);
    if (sec) sec.hidden = VIEWS[i] !== name;
  }
  $all("[data-nav]").forEach(function (a) {
    var on = a.getAttribute("data-nav") === name;
    a.classList.toggle("is-active", on);
    if (on) a.setAttribute("aria-current", "page");
    else a.removeAttribute("aria-current");
  });
  closeNav();
  window.scrollTo(0, 0);
  if (name === "stats") renderStats();
  if (name === "flashcards") refreshProgressUI();
  if (name === "admin" && typeof renderAdminSection === "function") renderAdminSection();
}

function go(view) {
  if (viewFromHash() === view) {
    showView(view);
  } else {
    window.location.hash = "#" + view;
  }
}

function initRouter() {
  window.addEventListener("hashchange", function () {
    showView(viewFromHash());
  });
  /* Bosh sahifadagi va boshqa joylardagi yordamchi tugmalar */
  document.addEventListener("click", function (e) {
    var goEl = e.target.closest("[data-go]");
    if (goEl) {
      e.preventDefault();
      go(goEl.getAttribute("data-go"));
    }
  });
  showView(viewFromHash());
}

/* ================= Mobil navigatsiya ================= */

function closeNav() {
  var header = $(".site-header");
  var btn = $("#navToggle");
  if (header) header.classList.remove("nav-open");
  if (btn) btn.setAttribute("aria-expanded", "false");
}

function initNav() {
  var header = $(".site-header");
  var btn = $("#navToggle");
  if (!header || !btn) return;
  btn.addEventListener("click", function () {
    var open = header.classList.toggle("nav-open");
    btn.setAttribute("aria-expanded", open ? "true" : "false");
  });
  $all("#mainNav a").forEach(function (a) {
    a.addEventListener("click", closeNav);
  });
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") closeNav();
  });
}

/* ================= Bosh sahifa: statistika va kun termini ================= */

var UZ_MONTHS = ["yanvar", "fevral", "mart", "aprel", "may", "iyun", "iyul", "avgust", "sentabr", "oktabr", "noyabr", "dekabr"];

function formatUzDate(d) {
  return d.getDate() + "-" + UZ_MONTHS[d.getMonth()] + ", " + d.getFullYear() + "-yil";
}

function renderHomeStats() {
  var uzCount = 0;
  for (var i = 0; i < TERMS.length; i++) {
    if (TERMS[i].uz && TERMS[i].enDef) uzCount++;
  }
  animateCount("statTerms", TERMS.length);
  animateCount("statUzNotes", uzCount);
  animateCount("statCards", TERMS.length);
  animateCount("statQuestions", typeof SAVOLLAR !== "undefined" ? SAVOLLAR.length : 0);
}

/* Raqamni 0 dan boshlab silliq hisoblab chiqadi (reduced-motion'da darhol) */
function animateCount(id, target) {
  var node = document.getElementById(id);
  if (!node) return;
  if (prefersReducedMotion() || !("requestAnimationFrame" in window)) {
    node.textContent = String(target);
    return;
  }
  var duration = 950;
  var startTs = null;
  function step(ts) {
    if (startTs === null) startTs = ts;
    var p = Math.min(1, (ts - startTs) / duration);
    var eased = 1 - Math.pow(1 - p, 3);
    node.textContent = String(Math.round(target * eased));
    if (p < 1) window.requestAnimationFrame(step);
  }
  window.requestAnimationFrame(step);
}

var dailyTerm = null;

function renderTermOfDay() {
  var wrap = $("#termOfDay");
  if (!wrap) return;
  if (!TERMS.length) {
    wrap.hidden = true;
    return;
  }
  wrap.hidden = false;
  var now = new Date();
  var start = new Date(now.getFullYear(), 0, 0);
  var dayOfYear = Math.floor((now - start) / 86400000);
  var term = TERMS[dayOfYear % TERMS.length];
  dailyTerm = term;
  $("#todDate").textContent = formatUzDate(now);
  $("#todTerm").textContent = term.en;
  $("#todUz").textContent = term.uz;
  $("#todNote").textContent = term.uzNote;
}

/* ================= ELEKTRON GLOSSARIY ================= */

var glossaryState = { search: "", filter: "all", sort: "id" };

function matchesSearch(term, q) {
  if (!q) return true;
  return (
    normalize(term.en).indexOf(q) !== -1 ||
    normalize(term.uz).indexOf(q) !== -1 ||
    normalize(term.enDef).indexOf(q) !== -1 ||
    normalize(term.uzNote).indexOf(q) !== -1 ||
    normalize(term.uzShort).indexOf(q) !== -1
  );
}

function matchesFilter(term, f) {
  if (f === "all") return true;
  if (f === "learned") return isLearned(term.id);
  if (f === "unlearned") return !isLearned(term.id);
  if (f === "fav") return isFav(term.id);
  return term.cat === f;
}

function sortTerms(list, mode) {
  var out = list.slice();
  if (mode === "az") {
    out.sort(function (a, b) { return a.en.localeCompare(b.en, "uz"); });
  } else if (mode === "za") {
    out.sort(function (a, b) { return b.en.localeCompare(a.en, "uz"); });
  } else if (mode === "unlearned") {
    out.sort(function (a, b) { return Number(isLearned(a.id)) - Number(isLearned(b.id)) || a.id - b.id; });
  } else if (mode === "learned") {
    out.sort(function (a, b) { return Number(isLearned(b.id)) - Number(isLearned(a.id)) || a.id - b.id; });
  } else {
    out.sort(function (a, b) { return a.id - b.id; });
  }
  return out;
}

var ICON_SPEAK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M11 5 6 9H2v6h4l5 4V5z"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/></svg>';
var ICON_STAR = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>';
var ICON_LAYERS = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83Z"/><path d="m22 17.65-9.17 4.16a2 2 0 0 1-1.66 0L2 17.65"/><path d="m22 12.65-9.17 4.16a2 2 0 0 1-1.66 0L2 12.65"/></svg>';

function buildTermCard(term, index, animate) {
  var card = el("article", "term-card");
  card.setAttribute("data-id", term.id);
  if (isLearned(term.id)) card.classList.add("is-learned");
  if (animate && !prefersReducedMotion()) {
    card.style.animation = "cardIn 0.3s " + Math.min(index, 8) * 0.035 + "s both";
  }

  var head = el("div", "term-head");
  head.appendChild(el("span", "term-id", term._custom ? "+" : String(term.id)));

  var titleWrap = el("div", "term-title-wrap");
  titleWrap.appendChild(el("h2", "term-en", term.en));
  titleWrap.appendChild(el("p", "term-uz", term.uz));
  head.appendChild(titleWrap);

  var actions = el("div", "term-actions");

  var speakBtn = el("button", "icon-btn");
  speakBtn.type = "button";
  speakBtn.setAttribute("data-speak", term.en);
  speakBtn.setAttribute("aria-label", "Tinglash: " + term.en);
  speakBtn.title = "Tinglash";
  speakBtn.innerHTML = ICON_SPEAK;
  actions.appendChild(speakBtn);

  var favBtn = el("button", "icon-btn fav-btn");
  favBtn.type = "button";
  favBtn.setAttribute("aria-pressed", isFav(term.id) ? "true" : "false");
  favBtn.setAttribute("aria-label", "Sevimlilarga qo'shish yoki olib tashlash: " + term.en);
  favBtn.title = "Sevimlilar";
  favBtn.innerHTML = ICON_STAR;
  if (isFav(term.id)) favBtn.classList.add("fav-active");
  actions.appendChild(favBtn);

  var jumpBtn = el("button", "icon-btn flash-jump-btn");
  jumpBtn.type = "button";
  jumpBtn.setAttribute("data-jump", term.id);
  jumpBtn.setAttribute("aria-label", "Kartochkada o'rganish: " + term.en);
  jumpBtn.title = "Kartochkada o'rganish";
  jumpBtn.innerHTML = ICON_LAYERS;
  actions.appendChild(jumpBtn);

  head.appendChild(actions);
  card.appendChild(head);

  card.appendChild(el("span", "term-badge", categoryName(term.cat)));
  if (term._custom) card.appendChild(el("span", "term-badge term-badge-custom", "Qo'shilgan termin"));
  card.appendChild(el("p", "term-def", term.enDef));

  var extra = el("div", "term-extra");
  extra.appendChild(el("p", "term-extra-label", "Qo'shimcha izoh"));
  extra.appendChild(el("p", "", term.uzNote));
  extra.appendChild(el("p", "term-extra-label", "Amaliy misol"));
  extra.appendChild(el("p", "term-example", term.example));
  card.appendChild(extra);

  var foot = el("div", "term-foot");
  var label = el("label", "learned-toggle" + (isLearned(term.id) ? " is-on" : ""));
  var cb = document.createElement("input");
  cb.type = "checkbox";
  cb.className = "learned-cb";
  cb.checked = isLearned(term.id);
  cb.setAttribute("aria-label", "O'rganilgan deb belgilash: " + term.en);
  label.appendChild(cb);
  label.appendChild(document.createTextNode("O'rganildi"));
  foot.appendChild(label);

  var detail = el("button", "detail-btn");
  detail.type = "button";
  detail.setAttribute("aria-expanded", "false");
  detail.textContent = "Batafsil o'qish";
  foot.appendChild(detail);

  card.appendChild(foot);
  return card;
}

function renderGlossary(animate) {
  var listEl = $("#termList");
  var emptyEl = $("#emptyState");
  var infoEl = $("#resultInfo");
  if (!listEl || !emptyEl || !infoEl) return;

  var q = normalize(glossaryState.search);
  var filtered = TERMS.filter(function (t) {
    return matchesSearch(t, q) && matchesFilter(t, glossaryState.filter);
  });
  filtered = sortTerms(filtered, glossaryState.sort);

  listEl.textContent = "";
  /* Optimallashtirish: barcha kartochkalar bitta fragment orqali joylanadi */
  var frag = document.createDocumentFragment();
  for (var i = 0; i < filtered.length; i++) {
    frag.appendChild(buildTermCard(filtered[i], i, animate));
  }
  listEl.appendChild(frag);

  var total = TERMS.length;
  if (q || glossaryState.filter !== "all") {
    infoEl.textContent = filtered.length + " ta natija topildi (jami " + total + " ta termin).";
  } else {
    infoEl.textContent = "Jami " + total + " ta termin ko'rsatilgan.";
  }
  emptyEl.hidden = filtered.length !== 0;
}

function initGlossary() {
  var search = $("#searchInput");
  if (search) {
    var searchTimer = null;
    search.addEventListener("input", function () {
      glossaryState.search = search.value;
      /* Optimallashtirish: har bir belgida emas, kichik pauzadan keyin qayta chizamiz */
      if (searchTimer) clearTimeout(searchTimer);
      searchTimer = window.setTimeout(function () { renderGlossary(false); }, 130);
    });
  }

  $all("#filterChips .chip").forEach(function (chip) {
    chip.addEventListener("click", function () {
      $all("#filterChips .chip").forEach(function (c) { c.classList.remove("is-active"); });
      chip.classList.add("is-active");
      glossaryState.filter = chip.getAttribute("data-filter") || "all";
      renderGlossary(true);
    });
  });

  var sortSel = $("#sortSelect");
  if (sortSel) {
    sortSel.addEventListener("change", function () {
      glossaryState.sort = sortSel.value;
      renderGlossary(true);
    });
  }

  var exportBtn = $("#exportCsv");
  if (exportBtn) exportBtn.addEventListener("click", exportCsv);

  var printB = $("#printBtn");
  if (printB) printB.addEventListener("click", function () { window.print(); });

  /* Kartochkalar ichidagi amallar (delegatsiya) */
  var listEl = $("#termList");
  if (listEl) {
    listEl.addEventListener("click", function (e) {
      var speakBtn = e.target.closest("[data-speak]");
      if (speakBtn) {
        speak(speakBtn.getAttribute("data-speak"));
        return;
      }
      var favBtn = e.target.closest(".fav-btn");
      if (favBtn) {
        var cardF = favBtn.closest(".term-card");
        var idF = Number(cardF.getAttribute("data-id"));
        toggleFav(idF);
        var on = isFav(idF);
        favBtn.classList.toggle("fav-active", on);
        favBtn.setAttribute("aria-pressed", on ? "true" : "false");
        toast(on ? "Termin sevimlilarga qo'shildi." : "Termin sevimlilardan olib tashlandi.");
        renderGlossary();
        return;
      }
      var jumpBtn = e.target.closest(".flash-jump-btn");
      if (jumpBtn) {
        jumpToFlashcards(Number(jumpBtn.getAttribute("data-jump")));
        return;
      }
      var detailBtn = e.target.closest(".detail-btn");
      if (detailBtn) {
        var cardD = detailBtn.closest(".term-card");
        var expanded = cardD.classList.toggle("expanded");
        detailBtn.setAttribute("aria-expanded", expanded ? "true" : "false");
        detailBtn.textContent = expanded ? "Yopish" : "Batafsil o'qish";
      }
    });
    listEl.addEventListener("change", function (e) {
      var cb = e.target.closest(".learned-cb");
      if (cb) {
        var cardL = cb.closest(".term-card");
        var idL = Number(cardL.getAttribute("data-id"));
        markLearned(idL, cb.checked);
        cardL.classList.toggle("is-learned", cb.checked);
        var lbl = cb.closest(".learned-toggle");
        if (lbl) lbl.classList.toggle("is-on", cb.checked);
        toast(cb.checked ? "Termin o'rganilgan deb belgilandi." : "Belgi olib tashlandi.");
        renderGlossary();
      }
    });
  }
}

/* ================= CSV eksport ================= */

function csvCell(value) {
  var s = String(value == null ? "" : value);
  if (/[",;\n\r]/.test(s)) {
    s = '"' + s.replace(/"/g, '""') + '"';
  }
  return s;
}

function exportCsv() {
  var header = ["Atama", "Qisqa ta'rif", "To'liq ta'rif", "Qo'shimcha izoh", "Amaliy misol", "Kategoriya"];
  var lines = [header.join(",")];
  sortTerms(TERMS, "id").forEach(function (t) {
    lines.push([
      csvCell(t.en),
      csvCell(t.uz),
      csvCell(t.enDef),
      csvCell(t.uzNote),
      csvCell(t.example),
      csvCell(categoryName(t.cat))
    ].join(","));
  });
  /* UTF-8 BOM — Excel o'zbekcha belgilarni to'g'ri ko'rsatishi uchun */
  var blob = new Blob(["\uFEFF" + lines.join("\r\n")], { type: "text/csv;charset=utf-8;" });
  var url = URL.createObjectURL(blob);
  var a = document.createElement("a");
  a.href = url;
  a.download = "jurnalistika-glossariy.csv";
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
  toast("Glossariy CSV fayl sifatida yuklab olindi.");
}

/* ================= FLASHCARDS ================= */

var flash = { deck: [], pos: 0, flipped: false };

function buildDeck() {
  var scope = state.scope;
  var ids = [];
  if (scope === "unlearned") {
    TERMS.forEach(function (t) {
      if (!isLearned(t.id)) ids.push(t.id);
    });
    if (ids.length === 0) {
      toast("Barcha terminlar o'rganilgan! Barcha terminlar rejimiga o'tildi.");
      state.scope = "all";
      var radio = $("#scopeAll");
      if (radio) radio.checked = true;
      TERMS.forEach(function (t) { ids.push(t.id); });
    }
  } else {
    TERMS.forEach(function (t) { ids.push(t.id); });
  }
  if (ids.length === 0) {
    toast("Hozircha terminlar mavjud emas — Boshqaruv paneli orqali qo'shing.");
  }
  flash.deck = ids;
  flash.pos = 0;
  flash.flipped = false;
  renderCard();
}

function renderCard() {
  var cardEl = $("#flashCard");
  if (!cardEl) return;
  if (flash.deck.length === 0) {
    $("#flashNumber").textContent = "0 / 0";
    $("#flashTerm").textContent = "Terminlar mavjud emas";
    $("#flashUz").textContent = "";
    $("#flashEnDef").textContent = "";
    $("#flashUzNote").textContent = "Boshqaruv paneli orqali yangi termin qo'shing yoki yashirilgan terminlarni qayta ko'rsating.";
    $("#flashExample").textContent = "";
    var counterEl = $("#flashCounter");
    if (counterEl) counterEl.textContent = "";
    cardEl.classList.remove("flipped");
    flash.flipped = false;
    var flipBtn0 = $("#flipCard");
    if (flipBtn0) flipBtn0.textContent = "Ta'rifni ko'rish";
    return;
  }
  var term = termById(flash.deck[flash.pos]);
  if (!term) return;

  $("#flashNumber").textContent = "Termin " + (flash.pos + 1) + " / " + flash.deck.length;
  $("#flashTerm").textContent = term.en;
  $("#flashUz").textContent = term.uz;
  $("#flashEnDef").textContent = term.enDef;
  $("#flashUzNote").textContent = term.uzNote;
  $("#flashExample").textContent = term.example;
  var termCur = termById(flash.deck[flash.pos]);
  var countEl = $("#flashCounter");
  if (countEl && termCur) {
    countEl.textContent = categoryName(termCur.cat) + " \u00B7 " + (isLearned(termCur.id) ? "o'rganilgan" : "o'rganilmagan");
  }

  cardEl.classList.toggle("flipped", flash.flipped);
  cardEl.setAttribute("aria-label", flash.flipped ? "Ta'rifni yashirish" : "Ta'rifni ko'rish");

  var flipBtn = $("#flipCard");
  if (flipBtn) flipBtn.textContent = flash.flipped ? "Ta'rifni yashirish" : "Ta'rifni ko'rish";

  var speakBtn = $("#flashSpeak");
  if (speakBtn) speakBtn.setAttribute("aria-label", "Tinglash: " + term.en);
}

function flipCard() {
  flash.flipped = !flash.flipped;
  var cardEl = $("#flashCard");
  if (cardEl) cardEl.classList.toggle("flipped", flash.flipped);
  var flipBtn = $("#flipCard");
  if (flipBtn) flipBtn.textContent = flash.flipped ? "Ta'rifni yashirish" : "Ta'rifni ko'rish";
}

function nextCard() {
  if (flash.deck.length === 0) return;
  flash.pos = (flash.pos + 1) % flash.deck.length;
  flash.flipped = false;
  renderCard();
}

function prevCard() {
  if (flash.deck.length === 0) return;
  flash.pos = (flash.pos - 1 + flash.deck.length) % flash.deck.length;
  flash.flipped = false;
  renderCard();
}

function currentCardTerm() {
  return flash.deck.length ? termById(flash.deck[flash.pos]) : null;
}

function refreshProgressUI() {
  var learned = learnedCount();
  var total = TERMS.length;
  var pct = total > 0 ? Math.round((learned / total) * 100) : 0;
  var label = $("#flashProgressLabel");
  var percent = $("#flashPercent");
  var bar = $("#flashProgressBar");
  var track = $("#flashProgressTrack");
  if (label) label.textContent = learned + " / " + total + " termin o'rganildi (" + pct + "%)";
  if (percent) percent.textContent = pct + "%";
  /* GPU tezlashtirilgan animatsiya: width o'rniga transform: scaleX */
  if (bar) bar.style.transform = "scaleX(" + (pct / 100) + ")";
  if (track) track.setAttribute("aria-valuenow", String(pct));
  renderRepeatList();
}

function renderRepeatList() {
  var list = $("#repeatList");
  var empty = $("#repeatEmpty");
  var count = $("#repeatCount");
  var onlyBtn = $("#repeatOnlyBtn");
  if (!list || !empty || !count) return;

  list.textContent = "";
  count.textContent = String(state.repeat.length);
  empty.hidden = state.repeat.length !== 0;
  if (onlyBtn) onlyBtn.disabled = state.repeat.length === 0;

  state.repeat.forEach(function (id) {
    var term = termById(id);
    if (!term) return;
    var li = el("li");
    var txt = el("div");
    txt.appendChild(el("span", "rep-en", term.en));
    txt.appendChild(el("span", "rep-uz", term.uz));
    li.appendChild(txt);
    var rm = el("button", "btn btn-ghost btn-sm");
    rm.type = "button";
    rm.textContent = "Ro'yxatdan olish";
    rm.setAttribute("aria-label", "Takrorlash ro'yxatidan olish: " + term.en);
    rm.addEventListener("click", function () {
      markRepeat(id, false);
      renderRepeatList();
      renderGlossary();
      toast("Termin takrorlash ro'yxatidan olib tashlandi.");
    });
    li.appendChild(rm);
    list.appendChild(li);
  });
}

function jumpToFlashcards(id) {
  /* Umumiy ro'yxatga o'tib, kerakli terminni ko'rsatamiz */
  state.scope = "all";
  var radioAll = $("#scopeAll");
  if (radioAll) radioAll.checked = true;
  var radioU = $("#scopeUnlearned");
  if (radioU) radioU.checked = false;
  var ids = TERMS.map(function (t) { return t.id; });
  flash.deck = ids;
  flash.pos = Math.max(0, ids.indexOf(id));
  flash.flipped = false;
  go("flashcards");
  renderCard();
  refreshProgressUI();
}

function initFlashcards() {
  var cardEl = $("#flashCard");
  if (cardEl) {
    cardEl.addEventListener("click", function () { flipCard(); });
    cardEl.addEventListener("keydown", function (e) {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        flipCard();
      }
    });
  }

  var fs = $("#flashSpeak");
  if (fs) {
    fs.addEventListener("click", function (e) {
      e.stopPropagation();
      var term = currentCardTerm();
      if (term) speak(term.en);
    });
  }

  var prev = $("#prevCard");
  if (prev) prev.addEventListener("click", prevCard);
  var next = $("#nextCard");
  if (next) next.addEventListener("click", nextCard);
  var flip = $("#flipCard");
  if (flip) flip.addEventListener("click", flipCard);

  var know = $("#knowBtn");
  if (know) {
    know.addEventListener("click", function () {
      var term = currentCardTerm();
      if (!term) return;
      markLearned(term.id, true);
      toast('"' + term.en + '" o\'rganilgan terminlar qatoriga qo\'shildi.');
      var fc = $("#flashCard");
      if (fc && !flash.flipped) {
        fc.classList.remove("pop");
        void fc.offsetWidth;
        fc.classList.add("pop");
      }
      nextCard();
    });
  }

  var rep = $("#repeatBtn");
  if (rep) {
    rep.addEventListener("click", function () {
      var term = currentCardTerm();
      if (!term) return;
      markRepeat(term.id, true);
      toast('"' + term.en + '" takrorlash ro\'yxatiga qo\'shildi.');
      nextCard();
    });
  }

  var sh = $("#shuffleBtn");
  if (sh) {
    sh.addEventListener("click", function () {
      flash.deck = shuffle(flash.deck);
      flash.pos = 0;
      flash.flipped = false;
      renderCard();
      toast("Kartochkalar aralashtirildi.");
    });
  }

  var rst = $("#restartCards");
  if (rst) {
    rst.addEventListener("click", function () {
      buildDeck();
      toast("Kartochkalar boshidan boshlandi.");
    });
  }

  $all('input[name="scope"]').forEach(function (radio) {
    radio.addEventListener("change", function () {
      state.scope = radio.value;
      saveState();
      buildDeck();
    });
  });

  var onlyBtn = $("#repeatOnlyBtn");
  if (onlyBtn) {
    onlyBtn.addEventListener("click", function () {
      if (state.repeat.length === 0) return;
      flash.deck = state.repeat.slice();
      flash.pos = 0;
      flash.flipped = false;
      renderCard();
      toast("Faqat takrorlash ro'yxatidagi " + flash.deck.length + " ta termin ko'rsatilmoqda.");
    });
  }
}

/* Klaviatura boshqaruvi (faqat flashcards ko'rinishida) */
function initKeyboard() {
  document.addEventListener("keydown", function (e) {
    if (currentView !== "flashcards") return;
    var target = e.target;
    if (target && target.closest && target.closest("input, textarea, select, button, a, #flashCard")) return;
    if (e.key === "ArrowLeft") {
      e.preventDefault();
      prevCard();
    } else if (e.key === "ArrowRight") {
      e.preventDefault();
      nextCard();
    } else if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      flipCard();
    }
  });
}

/* ================= TEST TIZIMI ================= */

var MODE_LABELS = {
  "mc-en-uz": "Ta'rif bo'yicha topish",
  "mc-uz-en": "Ta'rifni tanlash",
  "match": "Atama va ta'rifni moslashtirish"
};

var quiz = { mode: null, questions: [], idx: 0, correct: 0, wrong: 0, mistakes: [], answered: false };

/* 1-rejim: ta'rif beriladi — atama topiladi.
   Baza: data.js dagi savollar banki + boshqaruv panelidan qo'shilgan
   terminlar uchun avtomatik tuziladigan savollar. */
function buildDefTermQuestions() {
  var questions = [];
  (typeof SAVOLLAR === "undefined" ? [] : SAVOLLAR).forEach(function (q) {
    questions.push({
      kind: "bank",
      text: q.s,
      options: shuffle(q.v),
      correct: q.v[q.t],
      explain: q.i
    });
  });
  var custom = TERMS.filter(function (t) { return t._custom; });
  custom.forEach(function (term) {
    var others = shuffle(TERMS.filter(function (t) { return t.id !== term.id; })).slice(0, 3);
    var options = shuffle([term.en].concat(others.map(function (o) { return o.en; })));
    questions.push({
      kind: "term",
      term: term,
      text: "Ta'rif: «" + term.enDef + "» — bu qaysi atama?",
      options: options,
      correct: term.en,
      explain: term.uz + "."
    });
  });
  return shuffle(questions);
}

/* 2-rejim: atama beriladi — ta'rif tanlanadi (barcha terminlardan avtomatik tuziladi) */
function buildTermDefQuestions() {
  var catMap = {};
  TERMS.forEach(function (t) {
    if (!catMap[t.cat]) catMap[t.cat] = [];
    catMap[t.cat].push(t);
  });
  return shuffle(TERMS).map(function (term) {
    var sameCat = shuffle((catMap[term.cat] || []).filter(function (t) { return t.id !== term.id; }));
    var otherCat = shuffle(TERMS.filter(function (t) { return t.cat !== term.cat; }));
    var others = sameCat.concat(otherCat);
    var distractors = [];
    var usedTexts = {};
    usedTexts[term.uz] = true;
    for (var i = 0; i < others.length && distractors.length < 3; i++) {
      var txt = others[i].uz;
      if (!usedTexts[txt]) {
        usedTexts[txt] = true;
        distractors.push(txt);
      }
    }
    var options = shuffle([term.uz].concat(distractors));
    return {
      kind: "term",
      term: term,
      text: "«" + term.en + "» atamasi qaysi ta'rifga mos?",
      options: options,
      correct: term.uz,
      explain: term.enDef
    };
  });
}

function startQuiz(mode) {
  if (mode !== "mc-en-uz" && mode !== "mc-uz-en") return;
  if (TERMS.length < 4) {
    toast("Test uchun kamida 4 ta termin kerak. Boshqaruv paneli orqali qo'shishingiz mumkin.");
    return;
  }
  quiz.mode = mode;
  quiz.questions = mode === "mc-en-uz" ? buildDefTermQuestions() : buildTermDefQuestions();
  quiz.idx = 0;
  quiz.correct = 0;
  quiz.wrong = 0;
  quiz.mistakes = [];
  showQuizRunner();
  renderQuestion();
}

function showQuizRunner() {
  $("#quizIntro").hidden = true;
  $("#quizResult").hidden = true;
  $("#matchBoard").hidden = true;
  $("#matchResult").hidden = true;
  $("#quizRunner").hidden = false;
  $("#quizModeLabel").textContent = MODE_LABELS[quiz.mode];
}

function showQuizIntro() {
  $("#quizRunner").hidden = true;
  $("#quizResult").hidden = true;
  $("#matchBoard").hidden = true;
  $("#matchResult").hidden = true;
  $("#quizIntro").hidden = false;
}

function renderQuestion() {
  var q = quiz.questions[quiz.idx];
  quiz.answered = false;

  $("#quizProgressLabel").textContent = "Savol " + (quiz.idx + 1) + " / " + quiz.questions.length;
  $("#quizScoreLabel").textContent = "To'g'ri: " + quiz.correct;
  $("#quizProgressBar").style.transform = "scaleX(" + (quiz.idx / quiz.questions.length) + ")";

  $("#quizQuestion").textContent = q.text;

  var box = $("#quizOptions");
  box.textContent = "";
  var letters = ["A", "B", "C", "D"];
  q.options.forEach(function (opt, i) {
    var btn = el("button", "quiz-option");
    btn.type = "button";
    btn.setAttribute("data-index", String(i));
    var letter = el("span", "opt-letter", letters[i]);
    btn.appendChild(letter);
    btn.appendChild(document.createTextNode(opt));
    btn.addEventListener("click", function () { answerQuestion(i); });
    box.appendChild(btn);
  });

  var fb = $("#quizFeedback");
  fb.hidden = true;
  fb.className = "quiz-feedback";
  var nx = $("#nextQuestion");
  nx.disabled = true;
  nx.textContent = quiz.idx === quiz.questions.length - 1 ? "Natijalarni ko'rish" : "Keyingi savol";
}

function answerQuestion(index) {
  if (quiz.answered) return;
  quiz.answered = true;
  var q = quiz.questions[quiz.idx];
  var chosen = q.options[index];
  var isOk = chosen === q.correct;

  var buttons = $all("#quizOptions .quiz-option");
  buttons.forEach(function (b) {
    b.disabled = true;
    var optText = b.textContent.slice(1).trim(); /* harf belgisini olib tashlash */
    if (optText === q.correct) {
      b.classList.add("is-correct");
    } else if (optText === chosen && !isOk) {
      b.classList.add("is-wrong");
    } else {
      b.classList.add("is-dim");
    }
  });

  if (isOk) quiz.correct++;
  else {
    quiz.wrong++;
    quiz.mistakes.push({
      name: q.kind === "bank" ? q.correct : q.term.en,
      correct: q.correct,
      chosen: chosen
    });
  }
  $("#quizScoreLabel").textContent = "To'g'ri: " + quiz.correct;

  var fb = $("#quizFeedback");
  fb.hidden = false;
  fb.className = "quiz-feedback " + (isOk ? "is-ok" : "is-bad");
  fb.textContent = "";
  var title = el("p", "feedback-title", isOk ? "To'g'ri javob!" : "Noto'g'ri javob.");
  var body = el("p", "", q.kind === "bank"
    ? "To'g'ri javob: «" + q.correct + "». " + (q.explain || "")
    : (q.term ? q.term.en + " — " + q.term.uz + ". " : "To'g'ri javob: «" + q.correct + "». ") + (q.explain || ""));
  fb.appendChild(title);
  fb.appendChild(body);

  var nx = $("#nextQuestion");
  nx.disabled = false;
  nx.focus();
}

function nextQuestion() {
  quiz.idx++;
  if (quiz.idx >= quiz.questions.length) {
    finishQuiz();
  } else {
    renderQuestion();
  }
}

function finishQuiz() {
  var total = quiz.questions.length;
  var pct = Math.round((quiz.correct / total) * 100);
  state.quizzes.push({ d: new Date().toISOString(), m: quiz.mode, s: quiz.correct, t: total });
  saveState();

  $("#quizRunner").hidden = true;
  var res = $("#quizResult");
  res.hidden = false;

  var ring = $("#resultRing");
  ring.style.setProperty("--p", String(pct));
  if (pct >= 80) ring.style.setProperty("--ring-color", "var(--success)");
  else if (pct >= 60) ring.style.setProperty("--ring-color", "var(--warning)");
  else ring.style.setProperty("--ring-color", "var(--danger)");
  $("#resultPct").textContent = pct + "%";
  $("#resultMessage").textContent =
    pct >= 85 ? "Ajoyib natija! Bilimingiz juda yaxshi mustahkamlangan."
    : pct >= 60 ? "Yaxshi natija. Xato qilingan terminlarni takrorlab chiqing."
    : "Natijani yaxshilash uchun terminlarni yana bir bor o'rganib chiqing.";

  $("#resultCorrect").textContent = String(quiz.correct);
  $("#resultWrong").textContent = String(quiz.wrong);
  $("#resultTotal").textContent = String(total);

  var wrap = $("#resultMistakesWrap");
  var ul = $("#resultMistakes");
  ul.textContent = "";
  if (quiz.mistakes.length > 0) {
    wrap.hidden = false;
    quiz.mistakes.forEach(function (m) {
      var li = el("li", "", "«" + m.name + "» — to'g'ri javob: «" + m.correct + "» (siz tanlaganingiz: «" + m.chosen + "»)");
      ul.appendChild(li);
    });
  } else {
    wrap.hidden = true;
  }

  window.scrollTo(0, 0);
  toast("Test yakunlandi va natijalar saqlandi.");
}

function initQuiz() {
  $all("[data-quiz-mode]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var mode = btn.getAttribute("data-quiz-mode");
      if (mode === "match") startMatch();
      else startQuiz(mode);
    });
  });

  var nx = $("#nextQuestion");
  if (nx) nx.addEventListener("click", nextQuestion);

  var ex = $("#quizExit");
  if (ex) {
    ex.addEventListener("click", function () {
      if (window.confirm("Testni to'xtatmoqchimisiz? Joriy urinish natijalari saqlanmaydi.")) {
        showQuizIntro();
      }
    });
  }

  var retake = $("#retakeQuiz");
  if (retake) retake.addEventListener("click", function () { startQuiz(quiz.mode); });

  var toG = $("#toGlossary");
  if (toG) toG.addEventListener("click", function () { go("glossary"); });

  var mEx = $("#matchExit");
  if (mEx) mEx.addEventListener("click", showQuizIntro);

  var mAgain = $("#matchAgain");
  if (mAgain) mAgain.addEventListener("click", startMatch);

  var mHome = $("#matchHome");
  if (mHome) mHome.addEventListener("click", showQuizIntro);
}

/* ---------- Moslashtirish rejimi ---------- */

var match = { pairs: [], total: 6, selLeft: null, selRight: null, paired: 0, firstTry: 0, mistakes: 0, errors: {}, lock: false };

function startMatch() {
  if (TERMS.length < 3) {
    toast("Moslashtirish uchun kamida 3 ta termin kerak. Boshqaruv paneli orqali qo'shishingiz mumkin.");
    return;
  }
  var total = Math.min(6, TERMS.length);
  var picked = shuffle(TERMS).slice(0, total);
  match.total = total;
  match.pairs = picked;
  match.selLeft = null;
  match.selRight = null;
  match.paired = 0;
  match.firstTry = 0;
  match.mistakes = 0;
  match.errors = {};
  match.lock = false;

  $("#quizIntro").hidden = true;
  $("#quizResult").hidden = true;
  $("#quizRunner").hidden = true;
  $("#matchResult").hidden = true;
  $("#matchBoard").hidden = false;
  $("#matchStatus").textContent = "0 / " + total + " juftlik topildi";

  var left = $("#matchLeft");
  var right = $("#matchRight");
  left.textContent = "";
  right.textContent = "";

  picked.forEach(function (t) {
    var btn = el("button", "match-item");
    btn.type = "button";
    btn.setAttribute("data-left", String(t.id));
    btn.textContent = t.en;
    btn.addEventListener("click", function () { pickLeft(t.id, btn); });
    left.appendChild(btn);
  });

  shuffle(picked).forEach(function (t) {
    var btn = el("button", "match-item");
    btn.type = "button";
    btn.setAttribute("data-right", String(t.id));
    btn.textContent = t.uz;
    btn.addEventListener("click", function () { pickRight(t.id, btn); });
    right.appendChild(btn);
  });

  window.scrollTo(0, 0);
}

function clearSelection() {
  match.selLeft = null;
  match.selRight = null;
  $all("#matchLeft .match-item").forEach(function (b) { b.classList.remove("is-selected"); });
  $all("#matchRight .match-item").forEach(function (b) { b.classList.remove("is-selected"); });
}

function pickLeft(id, btn) {
  if (match.lock || btn.disabled) return;
  if (btn.classList.contains("is-paired")) return;
  var wasSame = match.selLeft === id;
  $all("#matchLeft .match-item").forEach(function (b) { b.classList.remove("is-selected"); });
  if (wasSame) {
    match.selLeft = null;
    return;
  }
  btn.classList.add("is-selected");
  match.selLeft = id;
  tryPair();
}

function pickRight(id, btn) {
  if (match.lock || btn.disabled) return;
  if (btn.classList.contains("is-paired")) return;
  var wasSame = match.selRight === id;
  $all("#matchRight .match-item").forEach(function (b) { b.classList.remove("is-selected"); });
  if (wasSame) {
    match.selRight = null;
    return;
  }
  btn.classList.add("is-selected");
  match.selRight = id;
  tryPair();
}

function tryPair() {
  if (match.selLeft == null || match.selRight == null) return;
  var leftBtn = document.querySelector('#matchLeft [data-left="' + match.selLeft + '"]');
  var rightBtn = document.querySelector('#matchRight [data-right="' + match.selRight + '"]');
  if (!leftBtn || !rightBtn) { clearSelection(); return; }

  if (match.selLeft === match.selRight) {
    leftBtn.classList.remove("is-selected");
    rightBtn.classList.remove("is-selected");
    leftBtn.classList.add("is-paired");
    rightBtn.classList.add("is-paired");
    leftBtn.disabled = true;
    rightBtn.disabled = true;
    if (!match.errors[match.selLeft]) match.firstTry++;
    match.paired++;
    clearSelection();
    $("#matchStatus").textContent = match.paired + " / " + match.total + " juftlik topildi";
    if (match.paired === match.total) finishMatch();
  } else {
    match.mistakes++;
    match.errors[match.selLeft] = true;
    match.lock = true;
    leftBtn.classList.add("is-error");
    rightBtn.classList.add("is-error");
    $("#matchStatus").textContent = "Bu juftlik to'g'ri kelmadi — yana urinib ko'ring";
    setTimeout(function () {
      leftBtn.classList.remove("is-error");
      rightBtn.classList.remove("is-error");
      clearSelection();
      match.lock = false;
    }, 450);
  }
}

function finishMatch() {
  var pct = Math.round((match.firstTry / match.total) * 100);
  state.quizzes.push({ d: new Date().toISOString(), m: "match", s: match.firstTry, t: match.total });
  saveState();

  $("#matchBoard").hidden = true;
  var res = $("#matchResult");
  res.hidden = false;

  var ring = $("#matchRing");
  ring.style.setProperty("--p", String(pct));
  if (pct >= 80) ring.style.setProperty("--ring-color", "var(--success)");
  else if (pct >= 60) ring.style.setProperty("--ring-color", "var(--warning)");
  else ring.style.setProperty("--ring-color", "var(--danger)");
  $("#matchPct").textContent = pct + "%";
  $("#matchMessage").textContent =
    pct >= 85 ? "Zo'r! Barcha juftliklarni deyarli xatosiz topdingiz."
    : pct >= 60 ? "Yaxshi. Ba'zi terminlarni yana takrorlash foydali bo'ladi."
    : "Har bir xato — o'rganish uchun imkoniyat. Yana bir urinib ko'ring.";

  $("#matchFirstTry").textContent = String(match.firstTry);
  $("#matchMistakes").textContent = String(match.mistakes);
  $("#matchTotalPairs").textContent = String(match.total);

  window.scrollTo(0, 0);
  toast("Moslashtirish raundi yakunlandi va natija saqlandi.");
}

/* ================= STATISTIKA SAHIFASI ================= */

function quizPct(q) {
  return q.t > 0 ? Math.round((q.s / q.t) * 100) : 0;
}

function hasAnyActivity() {
  return state.learned.length > 0 || state.repeat.length > 0 || state.favorites.length > 0 || state.quizzes.length > 0;
}

function renderStats() {
  var empty = $("#statsEmpty");
  var content = $("#statsContent");
  if (!empty || !content) return;

  if (!hasAnyActivity()) {
    empty.hidden = false;
    content.hidden = true;
    return;
  }
  empty.hidden = true;
  content.hidden = false;

  var learned = state.learned.length;
  var total = TERMS.length;
  var learnPct = total > 0 ? Math.round((learned / total) * 100) : 0;

  $("#kpiTerms").textContent = String(total);
  $("#kpiLearned").textContent = String(learned);
  $("#kpiRepeat").textContent = String(state.repeat.length);
  $("#kpiLearnPct").textContent = learnPct + "%";

  var quizzes = state.quizzes;
  $("#kpiQuizzes").textContent = String(quizzes.length);
  if (quizzes.length > 0) {
    var lastQ = quizzes[quizzes.length - 1];
    var best = 0;
    var sum = 0;
    quizzes.forEach(function (q) {
      var p = quizPct(q);
      if (p > best) best = p;
      sum += p;
    });
    $("#kpiLast").textContent = quizPct(lastQ) + "%";
    $("#kpiBest").textContent = best + "%";
    $("#kpiAvg").textContent = Math.round(sum / quizzes.length) + "%";
  } else {
    $("#kpiLast").textContent = "—";
    $("#kpiBest").textContent = "—";
    $("#kpiAvg").textContent = "—";
  }

  var bar = $("#statsProgressBar");
  var track = $("#statsProgressTrack");
  if (bar) bar.style.transform = "scaleX(" + (learnPct / 100) + ")";
  if (track) track.setAttribute("aria-valuenow", String(learnPct));
  $("#statsProgressNote").textContent = total + " tadan " + learned + " tasi o'rganilgan. O'rganish foizi: " + learnPct + "%.";

  /* Kategoriyalar bo'yicha progress */
  var catBox = $("#categoryBars");
  catBox.textContent = "";
  CATEGORIES.forEach(function (c) {
    var inCat = TERMS.filter(function (t) { return t.cat === c.id; });
    if (inCat.length === 0) return; /* bo'sh kategoriya — bo'linishda xatoning oldini olish */
    var learnedInCat = inCat.filter(function (t) { return isLearned(t.id); }).length;
    var pct = Math.round((learnedInCat / inCat.length) * 100);

    var row = el("div", "cat-bar-row");
    row.appendChild(el("span", "cat-bar-name", c.name));
    row.appendChild(el("span", "cat-bar-value", learnedInCat + " / " + inCat.length));
    var trackEl = el("div", "cat-bar-track");
    var fill = el("div", "cat-bar-fill");
    fill.style.transform = "scaleX(" + (pct / 100) + ")";
    trackEl.appendChild(fill);
    row.appendChild(trackEl);
    catBox.appendChild(row);
  });

  /* Test tarixi (oxirgi 10 ta) */
  var hist = $("#quizHistory");
  var histNote = $("#quizHistoryNote");
  hist.textContent = "";
  if (quizzes.length === 0) {
    histNote.textContent = "Hali test topshirilmagan. Testlar bo'limidan boshlang.";
  } else {
    histNote.textContent = "Oxirgi " + Math.min(10, quizzes.length) + " ta test natijasi (jami " + quizzes.length + " ta test).";
    quizzes.slice(-10).reverse().forEach(function (q) {
      var p = quizPct(q);
      var d = new Date(q.d);
      var row = el("div", "qh-row");
      row.appendChild(el("span", "qh-meta", (MODE_LABELS[q.m] || q.m) + " — " + d.getDate() + "." + (d.getMonth() + 1) + "." + d.getFullYear() + " (" + q.s + "/" + q.t + ")"));
      row.appendChild(el("span", "qh-pct", p + "%"));
      var trackEl = el("div", "qh-track");
      var fill = el("div", "qh-fill");
      fill.style.transform = "scaleX(" + (p / 100) + ")";
      if (p >= 80) fill.style.background = "var(--success)";
      else if (p < 60) fill.style.background = "var(--danger)";
      trackEl.appendChild(fill);
      row.appendChild(trackEl);
      hist.appendChild(row);
    });
  }

  /* Takrorlash ro'yxati */
  var repList = $("#statsRepeatList");
  var repEmpty = $("#statsRepeatEmpty");
  repList.textContent = "";
  if (state.repeat.length === 0) {
    repEmpty.hidden = false;
  } else {
    repEmpty.hidden = true;
    state.repeat.forEach(function (id) {
      var t = termById(id);
      if (!t) return;
      var li = el("li");
      li.appendChild(el("span", "rep-en", t.en));
      li.appendChild(el("span", "rep-uz", t.uz));
      repList.appendChild(li);
    });
  }

  var lastAct = $("#lastActivity");
  if (state.lastActive) {
    var d = new Date(state.lastActive);
    lastAct.textContent = "Oxirgi faoliyat: " + d.getDate() + "." + (d.getMonth() + 1) + "." + d.getFullYear();
  } else {
    lastAct.textContent = "";
  }
}

function initStats() {
  var reset = $("#resetProgress");
  if (reset) {
    reset.addEventListener("click", function () {
      if (window.confirm("Barcha o'rganish natijalari va test tarixi o'chiriladi. Davom etasizmi?")) {
        state.learned = [];
        state.repeat = [];
        state.favorites = [];
        state.quizzes = [];
        saveState();
        refreshProgressUI();
        renderStats();
        renderGlossary();
        toast("Barcha natijalar tozalandi.");
      }
    });
  }
}

/* ================= Boshqaruv paneli bilan integratsiya ================= */

function sanitizeTermState() {
  /* O'chirilgan yoki yashirilgan terminlar bo'yicha eski belgilarni tozalash */
  state.learned = validIds(state.learned);
  state.repeat = validIds(state.repeat);
  state.favorites = validIds(state.favorites);
  saveState();
}

function refreshAllViews() {
  renderHomeStats();
  renderTermOfDay();
  renderGlossary(false);
  buildDeck();
  refreshProgressUI();
  updateQuizIntroCounts();
  if (currentView === "stats") renderStats();
  if (currentView === "admin" && typeof renderAdminSection === "function") renderAdminSection();
}

function initTermOfDayActions() {
  var tod = $("#termOfDay");
  if (!tod) return;
  tod.addEventListener("click", function (e) {
    if (e.target.closest("#todSpeak") && dailyTerm) {
      speak(dailyTerm.en);
    } else if (e.target.closest("#todLink")) {
      go("glossary");
    }
  });
}

function updateQuizIntroCounts() {
  var n = TERMS.length;
  var bank = (typeof SAVOLLAR === "undefined" ? 0 : SAVOLLAR.length) + TERMS.filter(function (t) { return t._custom; }).length;
  var m = Math.min(6, n);
  var a = $("#quizCountMcEnUz");
  if (a) a.textContent = "Ta'rif ko'rsatiladi — unga mos atamani to'g'ri tanlang. Jami " + bank + " ta savol.";
  var b = $("#quizCountMcUzEn");
  if (b) b.textContent = "Atama nomi ko'rsatiladi — unga mos ta'rifi toping. Jami " + n + " ta savol.";
  var c = $("#quizCountMatch");
  if (c) c.textContent = "Atamalarni tegishli izoh bilan bosish orqali juftlang. " + m + " juftlikdan iborat raund.";
}

/* ================= ISHGA TUSHIRISH ================= */

function init() {
  initDesign();
  initDesignPanel();
  initNav();
  initRouter();
  initSpeech();
  initTermOfDayActions();
  renderHomeStats();
  renderTermOfDay();
  initGlossary();
  renderGlossary(true);
  initFlashcards();
  buildDeck();
  refreshProgressUI();
  initKeyboard();
  initQuiz();
  initStats();
  if (typeof initAdmin === "function") initAdmin();
  updateQuizIntroCounts();
  initTicker();
  initReveal();
  initHeaderScroll();
  initRipple();

  if (!storage.ok) {
    toast("Diqqat: brauzeringiz ma'lumotlarni saqlashni cheklagan. O'rganish natijalari sahifa yangilanganda saqlanmaydi.", 7000);
  }

  saveState();
}

/* ================= Kreativ qatlam: ticker, reveal, ripple ================= */

/* Yanglar lentasi: uzluksiz aylanish uchun kontentni ikki barobar qilish */
function initTicker() {
  var track = $("#tickerTrack");
  if (!track || track.children.length === 0) return;
  if (prefersReducedMotion()) return;
  track.innerHTML += track.innerHTML;
}

/* Scroll paytida elementlarni paydo qilish */
function initReveal() {
  var items = $all("[data-reveal]");
  if (items.length === 0) return;
  if (prefersReducedMotion() || !("IntersectionObserver" in window)) return;
  items.forEach(function (node, i) {
    node.classList.add("reveal");
    node.style.setProperty("--reveal-delay", Math.min(i % 6, 5) * 70 + "ms");
  });
  var obs = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-in");
        obs.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: "0px 0px -30px 0px" });
  items.forEach(function (node) { obs.observe(node); });
}

/* Headerga scroll soyasi */
function initHeaderScroll() {
  var header = $(".site-header");
  if (!header) return;
  var upd = function () {
    header.classList.toggle("is-scrolled", window.scrollY > 6);
  };
  window.addEventListener("scroll", upd, { passive: true });
  upd();
}

/* Birlamchi tugmalarga material-ripple effekti */
function initRipple() {
  if (prefersReducedMotion()) return;
  document.addEventListener("pointerdown", function (e) {
    var btn = e.target.closest(".btn-primary, .btn-success");
    if (!btn || btn.disabled) return;
    var rect = btn.getBoundingClientRect();
    var d = Math.max(rect.width, rect.height) * 2.1;
    var s = document.createElement("span");
    s.className = "ripple";
    s.style.width = s.style.height = d + "px";
    s.style.left = (e.clientX - rect.left - d / 2) + "px";
    s.style.top = (e.clientY - rect.top - d / 2) + "px";
    btn.appendChild(s);
    setTimeout(function () {
      if (s.parentNode) s.parentNode.removeChild(s);
    }, 650);
  });
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", init);
} else {
  init();
}


