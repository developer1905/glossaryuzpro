/* ============================================================
   JURNALISTIKA — ELEKTRON GLOSSARIY | data.js
   Vazifasi: jurnalistikaga oid 30 ta o'zbekcha termin,
   kategoriyalar va bilimni sinash savollari bazasi.
   Barcha bo'limlar shu fayldan oladi.

   Termin maydonlari:
   id     — tartib raqami (1..30)
   en     — termin nomi (o'zbekcha atama)
   uz     — qisqa ta'rif (bir gaplik — moslashtirish testida ishlatiladi)
   enDef  — to'liq ta'rif
   uzNote — qo'shimcha izoh (o'xshash atamalardan farqi)
   example— amaliy misol
   cat    — kategoriya id
   ============================================================ */
"use strict";

/* Kategoriyalar (filtr va kartochka belgilari uchun) */
const CATEGORIES = [
  { id: "asos",  name: "Asosiy tushunchalar" },
  { id: "janr",  name: "Janrlar va materiallar" },
  { id: "etika", name: "Etika va tekshiruv" },
  { id: "media", name: "Media va raqamli" }
];

/* Har bir terminning to'liq ta'rifi o'zbek tilida, lotin yozuvida */
const TERMS = [
  {
    id: 1,
    en: "Intervyu",
    uz: "Ma'lumot va fikr olish maqsadida o'tkaziladigan savol-javob suhbati",
    enDef: "Jurnalistning biror shaxsdan ma'lumot olish, uning fikri, qarashlari yoki tajribasini yoritish maqsadida savol-javob shaklida suhbat o'tkazishi.",
    uzNote: "Intervyu reportajdan farq qiladi: intervyuda asosiy vosita savol-javob suhbati, reportajda esa voqea joyining jonli tasviri. Suhbatdoshning javoblari materialda iqtibos sifatida keltiriladi.",
    example: "Jurnalist viloyat hokimi bilan katta yo'l qurilishi haqida intervyu o'tkazdi.",
    cat: "janr"
  },
  {
    id: 2,
    en: "Reportaj",
    uz: "Voqea joyidan tezkor va jonli yoritiladigan janr",
    enDef: "Voqea-hodisani bevosita sodir bo'layotgan joyidan turib, tezkor, aniq va ta'sirchan tarzda yorituvchi jurnalistik janr. Unda voqea muhiti, ishtirokchilar va kuzatuvlar jonli tasvirlanadi.",
    uzNote: "Reportaj xabardan hajmi va ta'sirchanligi bilan farqlanadi: xabar faqat fakt yetkazsa, reportaj voqea muhiti, ishtirokchilar va kuzatuvlarni jonli tasvirlaydi.",
    example: "Muxbir suv toshqini bo'lgan hududdan jonli reportaj tayyorladi.",
    cat: "janr"
  },
  {
    id: 3,
    en: "Tahririyat",
    uz: "Materiallarni tayyorlaydigan va nashr etadigan ijodiy jamoa",
    enDef: "Gazeta, jurnal, telekanal, radio yoki boshqa ommaviy axborot vositasining materiallarni tayyorlash, tahrirlash va nashr etish yoki efirga uzatish bilan shug'ullanuvchi ijodiy va tashkiliy jamoasi.",
    uzNote: "Tahririyatni matbuot anjumani bilan aralashtirib yubormang: tahririyat — material tayyorlovchi jamoa, anjuman esa jurnalistlar uchun tashkil etiladigan uchrashuv.",
    example: "Tahririyat ertalabki brifingda kuning eng muhim mavzularini belgilab oldi.",
    cat: "asos"
  },
  {
    id: 4,
    en: "Jurnalist",
    uz: "Axborotni izlab, tekshirib, ommaga yetkazuvchi ijodiy kasb egasi",
    enDef: "Jamiyat uchun muhim bo'lgan axborotni izlash, yig'ish, tekshirish, tahlil qilish va ommaga yetkazish bilan shug'ullanuvchi ijodiy kasb egasi.",
    uzNote: "Jurnalist — keng tushuncha: muxbir, muharrir, sharhlovchi ham jurnalist kasbining alohida yo'nalishlaridir.",
    example: "Haqiqiy jurnalist har bir ma'lumotni nashr etishdan oldin tekshiradi.",
    cat: "asos"
  },
  {
    id: 5,
    en: "Muxbir",
    uz: "Muayyan hudud yoki mavzudan ma'lumot to'playdigan jurnalist",
    enDef: "Muayyan hudud, tashkilot yoki mavzuga oid voqea-hodisalar haqida ma'lumot to'playdigan va ularni ommaviy axborot vositasiga yetkazadigan jurnalist.",
    uzNote: "Muxbir muharrirdan farq qiladi: muxbir voqea joyida axborot to'playdi, muharrir esa tahririyatda materialni tahrirlaydi va sifatini nazorat qiladi.",
    example: "Parlamentdagi majlis haqida muxbir tezkor ma'lumot yetkazdi.",
    cat: "asos"
  },
  {
    id: 6,
    en: "Muharrir",
    uz: "Materiallar sifatini tekshirib, nashrga tayyorlaydigan mutaxassis",
    enDef: "Jurnalistik materiallarning mazmuni, tili, uslubi, aniqligi va tuzilishini tekshiradigan, ularni takomillashtiradigan hamda nashrga yoki efirga tayyorlaydigan mutaxassis.",
    uzNote: "Muharrir materialga mualliflik qilmaydi — u muallif matnini tuzatib, uslubni yaxshilab, nashr yoki efir uchun sifat kafolati bo'ladi.",
    example: "Muharrir maqoladagi xato va uslub nuqsonlarini tuzatib, nashrga tayyorladi.",
    cat: "asos"
  },
  {
    id: 7,
    en: "Maqola",
    uz: "Mavzuni yorituvchi yoki tahlil qiluvchi jurnalistik material",
    enDef: "Muayyan mavzu, voqea yoki muammoni yoritish, tushuntirish, tahlil qilish yoki muallif nuqtayi nazarini ifodalash maqsadida yoziladigan jurnalistik material.",
    uzNote: "Maqola xabardan hajmi va chuqurligi bilan farqlanadi: agar material faqat fakt yetkasa — xabar, uni tahlil qilsa yoki muallif fikrini bildirsa — maqola deyiladi.",
    example: "Bugungi sonning bosh sahifasida ta'lim islohoti haqidagi katta maqola chiqdi.",
    cat: "janr"
  },
  {
    id: 8,
    en: "Yangilik",
    uz: "Ahamiyatli yangi voqea haqidagi faktlarga asoslangan material",
    enDef: "Jamiyat uchun ahamiyatli, yangi yoki yaqinda sodir bo'lgan voqea-hodisa haqida faktlarga asoslangan holda tayyorlangan axborot materiali.",
    uzNote: "Yangilikning asosiy mezonlari: yangilik, dolzarblik, ishonchlilik va ommaviy ahamiyat. Eski yoki tekshirilmagan axborot yangilik bo'la olmaydi.",
    example: "Zilzila haqidagi yangilik bir necha daqiqada butun mamlakatga yetkazildi.",
    cat: "asos"
  },
  {
    id: 9,
    en: "Xabar",
    uz: "Voqea haqida qisqa va aniq ma'lumot beruvchi material",
    enDef: "Muayyan voqea, hodisa yoki holat haqida qisqa, aniq va tushunarli shaklda ma'lumot beruvchi jurnalistik material.",
    uzNote: "Xabar yangilikdan qisqaroq va sodda: unda faqat asosiy fakt — kim, nima, qachon, qayerda — yetkaziladi, tahlil va baho bo'lmaydi.",
    example: "Radio efirga ob-havo haqida qisqa xabar berdi.",
    cat: "asos"
  },
  {
    id: 10,
    en: "Lavha",
    uz: "Kuzatish va tasvirlash orqali jonli tasavvur hosil qiluvchi material",
    enDef: "Muayyan voqea, joy, shaxs yoki hayotiy holatni kuzatish va tasvirlash orqali yoritadigan, o'quvchi yoki tomoshabinda jonli tasavvur hosil qiluvchi jurnalistik material.",
    uzNote: "Lavha reportajga yaqin, biroq unda tezkorlik emas, kuzatuv va tasvirlash yetakchi. Ocherkdan farqi: lavha bitta holat yoki manzarani tasvirlasa, ocherk kengroq hayotiy materialni qamrab oladi.",
    example: "Bozor savdogarlarining mehnati haqidagi lavha o'quvchilar chuqur taassurot qoldirdi.",
    cat: "janr"
  },
  {
    id: 11,
    en: "Tahliliy maqola",
    uz: "Sabab va oqibatlarni dalillar bilan chuqur o'rganuvchi material",
    enDef: "Muayyan voqea yoki muammoning sabablari, rivojlanishi, oqibatlari va ahamiyatini faktlar hamda dalillar asosida chuqur o'rganuvchi jurnalistik material.",
    uzNote: "Oddiy maqoladan farqi — chuqurlik: tahliliy maqola voqeaning sabab-oqibat aloqalarini ochib beradi va har bir xulosasini dalillar bilan asoslaydi.",
    example: "Tahliliy maqola narxlarning o'sish sabablarini statistika bilan ochib berdi.",
    cat: "janr"
  },
  {
    id: 12,
    en: "Taqriz",
    uz: "Ijodiy asarni tahlil qilib baho beruvchi material",
    enDef: "Kitob, film, spektakl, ko'rgazma yoki boshqa ijodiy asarni tahlil qilib, uning mazmuni, yutuqlari va kamchiliklariga baho beruvchi jurnalistik material.",
    uzNote: "Taqriz faqat ijodiy asarlar — kitob, film, spektakl, ko'rgazma haqida yoziladi. Oddiy voqea yoki mavzu haqidagi baho material taqriz emas.",
    example: "Yosh rejissyorning yangi filmi haqida ijobiy taqriz yozildi.",
    cat: "janr"
  },
  {
    id: 13,
    en: "Feleton",
    uz: "Illatlarni hajv va kinoya orqali tanqid qiluvchi janr",
    enDef: "Jamiyatdagi illatlar, kamchiliklar yoki salbiy hodisalarni hajv, kinoya va badiiy tasvir vositalari orqali tanqid qiluvchi jurnalistik janr.",
    uzNote: "Feletonning asosiy qurollari — hajv, kinoya va keskin tanqid. U kulgili ko'rinsa-da, maqsadi illatni isloh qilishdir.",
    example: "Feleton yo'l ta'miridagi beparvolikni kinoya bilan tanqid qildi.",
    cat: "janr"
  },
  {
    id: 14,
    en: "Ocherk",
    uz: "Real fakt va badiiy tasvirni uyg'unlashtiruvchi janr",
    enDef: "Shaxs, guruh, voqea yoki ijtimoiy hodisani real faktlar va badiiy tasvir elementlari uyg'unligida yorituvchi jurnalistik janr.",
    uzNote: "Ocherkda real faktlar badiiy tasvir vositalari bilan yoritiladi. Feletondan farqi: ocherk tanqid uchun emas, tasvir va ulug'lash uchun yoziladi.",
    example: "Maktab o'qituvchisining fidoyiligi haqidagi ocherk o'quvchilarni hayajonga soldi.",
    cat: "janr"
  },
  {
    id: 15,
    en: "Bosh maqola",
    uz: "Tahririyat pozitsiyasini ifodalovchi asosiy maqola",
    enDef: "Tahririyatning muhim ijtimoiy, siyosiy yoki iqtisodiy masala yuzasidan pozitsiyasini ifodalovchi, odatda nashr uchun alohida ahamiyatga ega bo'lgan maqola.",
    uzNote: "Bosh maqola tahririyat nomidan yoziladi, shaxsiy muallif imzosi bo'lmaydi. Oddiy maqoladan farqi — u butun nashrning rasmiy pozitsiyasini bildiradi.",
    example: "Bugungi sonning bosh maqolasi islohotlar siyosatiga bag'ishlandi.",
    cat: "janr"
  },
  {
    id: 16,
    en: "Surishtiruv jurnalistikasi",
    uz: "Yashirin holatlarni dalillar orqali fosh etuvchi yo'nalish",
    enDef: "Yashirin qolgan yoki keng jamoatchilik uchun muhim bo'lgan holatlarni hujjatlar, dalillar, manbalar va tekshiruvlar orqali o'rganib, aniqlangan natijalarni ommaga taqdim etishga qaratilgan jurnalistika yo'nalishi.",
    uzNote: "Bu yo'nalish oddiy yangilik yoritishidan chuqurlik va davomiyligi bilan farqlanadi: har bir fakt hujjat va mustaqil manbalar bilan bir necha bor tekshiriladi.",
    example: "Surishtiruv jurnalistikasi yordamida byudjet mablag'larining suiiste'mol ishlatilgani fosh etildi.",
    cat: "etika"
  },
  {
    id: 17,
    en: "Faktlarni tekshirish",
    uz: "Ma'lumotlar ishonchliligini dalillar bilan tekshirish",
    enDef: "Axborotda keltirilgan ma'lumotlar, raqamlar, bayonotlar va da'volarning ishonchliligini hujjatlar, mustaqil manbalar va boshqa dalillar yordamida tekshirish jarayoni.",
    uzNote: "Faktlarni tekshirish shunchaki internetdan qidirish emas — asl hujjatlar, rasmiy statistika va mustaqil mutaxassislar bilan solishtirish jarayonidir.",
    example: "Nashr tarqalgan da'voni faktlarni tekshirish orqali rad etdi.",
    cat: "etika"
  },
  {
    id: 18,
    en: "Axborot manbasi",
    uz: "Jurnalist ma'lumot oladigan ishonchli manba",
    enDef: "Jurnalist ma'lumot oladigan shaxs, tashkilot, hujjat, rasmiy bayonot, ma'lumotlar to'plami yoki boshqa ishonchli axborot manbai.",
    uzNote: "Manba shaxs bo'lishi shart emas: hujjat, bayonot, statistik to'plam ham manba hisoblanadi. Manbaning ishonchliligi har bir materialning poydevori.",
    example: "Jurnalist o'z axborot manbasining ismini oshkor qilmaslikka rioya qildi.",
    cat: "etika"
  },
  {
    id: 19,
    en: "Sarlavha",
    uz: "Material mazmunini qisqa ifodalovchi e'tiborli matn",
    enDef: "Jurnalistik materialning asosiy mazmunini qisqa va aniq ifodalovchi, o'quvchi yoki tomoshabinning e'tiborini jalb qilishga xizmat qiluvchi matn.",
    uzNote: "Sarlavha kirish qismidan farq qiladi: sarlavha material ustidagi qisqa nom, kirish qismi esa matnning birinchi bo'lagi.",
    example: "Sarlavha material mazmunini aniq aks ettirishi kerak — mubolag'ga yo'l qo'yilmaydi.",
    cat: "janr"
  },
  {
    id: 20,
    en: "Kirish qismi",
    uz: "O'quvchini material mazmuniga olib kiradigan bosh qism",
    enDef: "Jurnalistik materialning boshida keladigan, mavzu, asosiy muammo yoki muhim faktni tanishtirib, o'quvchini material mazmuniga olib kiradigan qism.",
    uzNote: "Kirish qismi o'quvchini materialga tortadi va asosiy muammoni ko'rsatadi. Sarlavhadan farqi: u matn tarkibidagi bo'lak hisoblanadi.",
    example: "Kirish qismida o'quvchiga muammoning mohiyati qisqacha tushuntirildi.",
    cat: "janr"
  },
  {
    id: 21,
    en: "Dalil",
    uz: "Fikr va xulosani asoslaydigan tekshirilgan fakt",
    enDef: "Jurnalistik materialda bildirilgan fikr, da'vo yoki xulosani asoslash uchun foydalaniladigan tekshiriladigan fakt, hujjat, guvohlik, raqam yoki boshqa ishonchli ma'lumot.",
    uzNote: "Dalil fikrdan farqlanishi kerak: fikr — muallifning qarashi, dalil esa uni tasdiqlovchi tekshiriladigan fakt yoki hujjat.",
    example: "Jurnalist o'z xulosasini rasmiy statistika ma'lumotlari bilan dalillab berdi.",
    cat: "janr"
  },
  {
    id: 22,
    en: "Xolislik",
    uz: "Voqealarni adolatli, bir tomonlama bo'lmagan yoritish",
    enDef: "Jurnalistning voqea-hodisalarni shaxsiy manfaat, asossiz tarafkashlik yoki bir tomonlama qarashlar ta'sirida buzib ko'rsatmasdan, mavjud dalillarni adolatli yoritishga intilishi.",
    uzNote: "Xolislik bilan tarafkashlik qarama-qarshi tushunchalar: xolis jurnalist ikkala tomonning ham fikrini teng keltiradi, tarafkashlik esa bitta tomanga adolatsiz ustunlik beradi.",
    example: "Xolis muxbir suddagi ikki tomonning ham fikrini teng keltirdi.",
    cat: "etika"
  },
  {
    id: 23,
    en: "Media etikasi",
    uz: "Halollik va hurmatga asoslangan kasbiy qoidalar",
    enDef: "Jurnalist va ommaviy axborot vositalari faoliyatida halollik, aniqlik, xolislik, inson sha'ni va huquqlariga hurmat, shaxsiy hayot daxlsizligi kabi tamoyillarga rioya qilish qoidalari.",
    uzNote: "Media etikasi — qonun emas, axloqiy qoidalar majmui: u jurnalistning vijdon mas'uliyatiga tayanadi, biroq kasbiy jamoatchilik nazorati ham mavjud.",
    example: "Media etikasiga rioya qilib, jurnalist suhbatdoshning shaxsiy hayotiga tegmadi.",
    cat: "etika"
  },
  {
    id: 24,
    en: "Mualliflik huquqi",
    uz: "Muallif huquqlarini himoya qiluvchi qonunlar majmui",
    enDef: "Asar yoki ijodiy materialni yaratgan shaxsning qonunchilikda belgilangan huquqlarini himoya qiluvchi huquqiy normalar majmui. Jurnalistikada matn, surat, video va boshqa ijodiy mahsulotlardan foydalanishda mualliflik huquqiga rioya qilish muhimdir.",
    uzNote: "Mualliflik huquqi ruxsatsiz nusxalashni cheklaydi: boshqa manbadan olingan surat, matn yoki videodan foydalanishda muallifni ko'rsatish yoki ruxsat olish shart.",
    example: "Boshqa nashrning fotosuratini mualliflik huquqisiz ishlatish mumkin emas.",
    cat: "etika"
  },
  {
    id: 25,
    en: "Matbuot anjumani",
    uz: "Jurnalistlarga ma'lumot berish uchun tashkil etiladigan uchrashuv",
    enDef: "Tashkilot, davlat idorasi, jamoat arbobi yoki boshqa vakilning jurnalistlar bilan uchrashib, muhim masalalar bo'yicha ma'lumot berishi va savollarga javob qaytarishi uchun tashkil etiladigan tadbir.",
    uzNote: "Matbuot anjumani yozma press-relizdan farq qiladi: anjumanda jurnalistlar jonli savol berib, javob oladi.",
    example: "Vazirlik matbuot anjumani o'tkazib, jurnalistlar savollariga javob berdi.",
    cat: "media"
  },
  {
    id: 26,
    en: "Axborot byulleteni",
    uz: "Muntazam tayyorlanadigan axborot nashri",
    enDef: "Muayyan mavzu yoki faoliyat yo'nalishi bo'yicha muhim ma'lumotlarni muntazam ravishda jamlab, belgilangan auditoriyaga yetkazish uchun tayyorlanadigan axborot nashri.",
    uzNote: "Byulleten muntazamligi bilan ajralib turadi: u bir martalik e'lon emas, belgilangan davriylikda tayyorlanadigan nashr.",
    example: "Statistika agentligi oylik axborot byulletenini e'lon qildi.",
    cat: "media"
  },
  {
    id: 27,
    en: "Fotojurnalistika",
    uz: "Voqealarni fotografiya orqali hujjatlashtirish",
    enDef: "Voqea-hodisalar, insonlar va ijtimoiy hayotni fotografiya vositasida hujjatlashtirish va yoritishga asoslangan jurnalistika yo'nalishi.",
    uzNote: "Fotojurnalistika oddiy fotosuratdan hujjatliyligi va yangilik qiymati bilan farqlanadi: surat voqeani haqqoniy aks ettirishi kerak.",
    example: "Fotomuxbirning zilzila hududidan olgan suratlari keng tan olindi.",
    cat: "media"
  },
  {
    id: 28,
    en: "Radiojurnalistika",
    uz: "Materiallarni ovoz va nutq orqali yetkazish",
    enDef: "Axborot, suhbat, reportaj va boshqa jurnalistik materiallarni radio orqali ovoz, nutq va tovush vositalari yordamida tinglovchilarga yetkazishga asoslangan jurnalistika yo'nalishi.",
    uzNote: "Radiojurnalistikada asosiy vosita — ovoz: tinglovchi tasvirni ko'rmaydi, shuning uchun matn aniq, jonli va tasvirli bo'lishi talab qilinadi.",
    example: "Radiojurnalist suhbatdosh bilan jonli efirda suhbat qurdi.",
    cat: "media"
  },
  {
    id: 29,
    en: "Telejurnalistika",
    uz: "Axborotni tasvir va ovoz vositalari bilan yetkazish",
    enDef: "Axborot va voqea-hodisalarni tasvir, ovoz, suhbat, lavha va boshqa ekran vositalari orqali tomoshabinlarga yetkazishga asoslangan jurnalistika yo'nalishi.",
    uzNote: "Telejurnalistikada tasvir va ovoz birga ishlaydi: lavha, syujet va jonli reportaj tomoshabinga to'liq ko'rgazmali tasavvur beradi.",
    example: "Telejurnalist syujet va jonli lavha bilan yangiliklarni tomoshabinlarga yetkazdi.",
    cat: "media"
  },
  {
    id: 30,
    en: "Raqamli jurnalistika",
    uz: "Internet va raqamli texnologiyalarga asoslangan jurnalistika",
    enDef: "Internet va raqamli texnologiyalar yordamida axborotni yig'ish, tekshirish, tayyorlash, tarqatish va auditoriya bilan o'zaro aloqada bo'lishga asoslangan jurnalistika yo'nalishi.",
    uzNote: "Raqamli jurnalistika faqat saytdagi matn emas — multimedia, jonli efir, ijtimoiy tarmoqlar va auditoriya bilan o'zaro aloqa ham shu tushunchaga kiradi.",
    example: "Raqamli jurnalistika auditoriya bilan ijtimoiy tarmoqlar orqali muloqot qiladi.",
    cat: "media"
  }
];

/* Kategoriya nomini qaytarish */
function categoryName(id) {
  for (var i = 0; i < CATEGORIES.length; i++) {
    if (CATEGORIES[i].id === id) return CATEGORIES[i].name;
  }
  return "";
}

/* ============================================================
   BILIMNI SINASH SAVOLLARI (ta'rif bo'yicha topish rejimi)
   s — savol matni, v — 4 ta variant, t — to'g'ri javob indeksi (0..3),
   i — javob izohi. Savollar atamalar mazmunini tushunishga qaratilgan.
   ============================================================ */
const SAVOLLAR = [
  {
    s: "Jurnalistning biror shaxsdan ma'lumot olish maqsadida savol-javob shaklida o'tkazadigan suhbati qanday atalanadi?",
    v: ["Reportaj", "Intervyu", "Taqriz", "Lavha"],
    t: 1,
    i: "Intervyu — fikr, qarash va tajribani yoritish maqsadidagi savol-javob suhbati."
  },
  {
    s: "Jurnalist voqeani bevosita sodir bo'layotgan joyidan turib, tezkor va ta'sirchan tarzda yoritmoqda. U qaysi janrda ishlamoqda?",
    v: ["Feleton", "Bosh maqola", "Reportaj", "Taqriz"],
    t: 2,
    i: "Reportaj — voqea joyidan jonli kuzatuvlar bilan yoritiladigan janr."
  },
  {
    s: "Gazetaning materiallarni tayyorlash, tahrirlash va nashr etish bilan shug'ullanuvchi ijodiy jamoasi qanday ataladi?",
    v: ["Tahririyat", "Axborot manbasi", "Auditoriya", "Dalil"],
    t: 0,
    i: "Tahririyat — matbuot yoki telekanalning ijodiy va tashkiliy jamoasi."
  },
  {
    s: "Axborotni izlash, yig'ish, tekshirish va ommaga yetkazish bilan shug'ullanuvchi ijodiy kasb egasi kim?",
    v: ["Muharrir", "Muxbir", "Jurnalist", "Ocherkchi"],
    t: 2,
    i: "Jurnalist — axborotni izlovchi va ommaga yetkazuvchi ijodiy kasb egasi."
  },
  {
    s: "Muayyan hudud yoki mavzuga oid voqealar haqida ma'lumot to'playdigan va OAVga yetkazadigan jurnalist kim deb ataladi?",
    v: ["Muharrir", "Muxbir", "Taqrizchi", "Fotomuxbir"],
    t: 1,
    i: "Muxbir — hudud, tashkilot yoki mavzu bo'yicha ma'lumot to'playdigan jurnalist."
  },
  {
    s: "Materiallarning mazmuni, tili va aniqligini tekshirib, ularni nashrga yoki efirga tayyorlaydigan mutaxassis kim?",
    v: ["Muxbir", "Muharrir", "Jurnalist", "Manba"],
    t: 1,
    i: "Muharrir — materiallarni takomillashtirib, nashrga tayyorlaydigan mutaxassis."
  },
  {
    s: "Muayyan mavzuni yoritish yoki muallif nuqtayi nazarini ifodalash maqsadida yoziladigan jurnalistik material qanday atalanadi?",
    v: ["Xabar", "Byulleten", "Maqola", "Sarlavha"],
    t: 2,
    i: "Maqola — mavzuni yorituvchi, tushuntiruvchi yoki tahlil qiluvchi material."
  },
  {
    s: "Jamiyat uchun ahamiyatli, yaqinda sodir bo'lgan voqea haqida faktlarga asoslangan tayyorlangan material qanday ataladi?",
    v: ["Yangilik", "Taqriz", "Lavha", "Feleton"],
    t: 0,
    i: "Yangilik — yangi voqea haqidagi faktlarga asoslangan axborot materiali."
  },
  {
    s: "Voqea haqida qisqa, aniq va tushunarli shaklda ma'lumot beruvchi material qaysi atama bilan yuritiladi?",
    v: ["Maqola", "Ocherk", "Xabar", "Reportaj"],
    t: 2,
    i: "Xabar — qisqa, aniq va tushunarli ma'lumot beruvchi material."
  },
  {
    s: "Shaxs yoki hayotiy holatni kuzatish va tasvirlash orqali jonli tasavvur hosil qiluvchi material qanday atalanadi?",
    v: ["Lavha", "Xabar", "Sarlavha", "Anjuman"],
    t: 0,
    i: "Lavha — kuzatuv va tasvirlash orqali jonli tasavvur hosil qiladi."
  },
  {
    s: "Voqea yoki muammoning sabablari va oqibatlarini faktlar asosida chuqur o'rganuvchi material qaysi janrga mansub?",
    v: ["Taqriz", "Tahliliy maqola", "Xabar", "Yangilik"],
    t: 1,
    i: "Tahliliy maqola — sabab-oqibatlarni dalillar bilan chuqur o'rganadi."
  },
  {
    s: "Kitob, film yoki spektaklni tahlil qilib, yutuqlari va kamchiliklariga baho beruvchi material qanday atalanadi?",
    v: ["Taqriz", "Reportaj", "Intervyu", "Lavha"],
    t: 0,
    i: "Taqriz — ijodiy asarga baho beruvchi jurnalistik material."
  },
  {
    s: "Jamiyatdagi illat va kamchiliklarni hajv hamda kinoya orqali tanqid qiluvchi janr qaysi biri?",
    v: ["Ocherk", "Feleton", "Reportaj", "Bosh maqola"],
    t: 1,
    i: "Feleton — hajv va kinoya vositasida tanqid qiluvchi janr."
  },
  {
    s: "Shaxs yoki ijtimoiy hodisani real faktlar va badiiy tasvir uyg'unligida yorituvchi janr qanday atalanadi?",
    v: ["Feleton", "Taqriz", "Ocherk", "Xabar"],
    t: 2,
    i: "Ocherk — real fakt va badiiy tasvirni uyg'unlashtiradi."
  },
  {
    s: "Tahririyatning muhim masala yuzasidan pozitsiyasini ifodalovchi maqola qanday ataladi?",
    v: ["Bosh maqola", "Tahliliy maqola", "Taqriz", "Ocherk"],
    t: 0,
    i: "Bosh maqola — tahririyat pozitsiyasini ifodalaydi va alohida ahamiyatga ega."
  },
  {
    s: "Yashirin qolgan holatlarni hujjatlar va dalillar orqali o'rganib, ommaga taqdim etuvchi yo'nalish qaysi biri?",
    v: ["Fotojurnalistika", "Surishtiruv jurnalistikasi", "Radiojurnalistika", "Telejurnalistika"],
    t: 1,
    i: "Surishtiruv jurnalistikasi — dalillar orqali yashirin holatlarni fosh etadi."
  },
  {
    s: "Ma'lumotlar, raqamlar va da'volarning ishonchliligini hujjatlar va mustaqil manbalar yordamida tekshirish qanday atalanadi?",
    v: ["Xolislik", "Media etikasi", "Faktlarni tekshirish", "Mualliflik huquqi"],
    t: 2,
    i: "Faktlarni tekshirish — ma'lumotlar ishonchliligini dalillar bilan tekshirish jarayoni."
  },
  {
    s: "Jurnalist ma'lumot oladigan shaxs, hujjat yoki rasmiy bayonot qanday umumiy nom bilan ataladi?",
    v: ["Auditoriya", "Axborot manbasi", "Tahririyat", "Lavha"],
    t: 1,
    i: "Axborot manbasi — jurnalist ma'lumot oladigan ishonchli manba."
  },
  {
    s: "Materialning asosiy mazmunini qisqa ifodalab, e'tiborni jalb qiluvchi matn qanday atalanadi?",
    v: ["Kirish qismi", "Dalil", "Sarlavha", "Lavha"],
    t: 2,
    i: "Sarlavha — mazmunni qisqa ifodab, e'tibor jalb qiladi."
  },
  {
    s: "Materialning boshida kelib, o'quvchini mazmuniga olib kiradigan qism qanday atalanadi?",
    v: ["Kirish qismi", "Sarlavha", "Dalil", "Byulleten"],
    t: 0,
    i: "Kirish qismi — mavzu va muhim faktni tanishtirib, mazmunga olib kiradi."
  },
  {
    s: "Materialdagi fikr yoki xulosani asoslash uchun ishlatiladigan tekshiriladigan fakt qanday atalanadi?",
    v: ["Xolislik", "Dalil", "Manba", "Etika"],
    t: 1,
    i: "Dalil — fikr va xulosani asoslaydigan tekshirilgan fakt yoki hujjat."
  },
  {
    s: "Voqea-hodisalarni shaxsiy manfaat yoki tarafkashliksiz, adolatli yoritishga intilish qanday tamoyil?",
    v: ["Xolislik", "Feleton", "Anjuman", "Reportaj"],
    t: 0,
    i: "Xolislik — buzib ko'rsatmasdan, dalillarni adolatli yoritish."
  },
  {
    s: "Jurnalist faoliyatida halollik, aniqlik va inson sha'niga hurmatga oid qoidalar majmui qanday atalanadi?",
    v: ["Mualliflik huquqi", "Media etikasi", "Dalil", "Sarlavha"],
    t: 1,
    i: "Media etikasi — halollik, aniqlik va hurmat tamoyillariga asoslangan qoidalar."
  },
  {
    s: "Asarni yaratgan shaxsning huquqlarini himoya qiluvchi qonunlar majmui qanday ataladi?",
    v: ["Media etikasi", "Xolislik", "Mualliflik huquqi", "Axborot manbasi"],
    t: 2,
    i: "Mualliflik huquqi — muallif huquqlarini himoya qiluvchi huquqiy normalar."
  },
  {
    s: "Tashkilot vakili jurnalistlar bilan uchrashib, ma'lumot berishi va savollarga javob berishi uchun qanday tadbir tashkil etiladi?",
    v: ["Matbuot anjumani", "Taqriz", "Reportaj", "Lavha"],
    t: 0,
    i: "Matbuot anjumani — jurnalistlar uchun tashkil etiladigan uchrashuv."
  },
  {
    s: "Muayyan mavzudagi ma'lumotlarni muntazam jamlab, belgilangan auditoriyaga yetkazuvchi nashr qanday atalanadi?",
    v: ["Maqola", "Axborot byulleteni", "Bosh maqola", "Tahririyat"],
    t: 1,
    i: "Axborot byulleteni — muntazam tayyorlanadigan axborot nashri."
  },
  {
    s: "Voqea-hodisalarni fotografiya vositasida hujjatlashtirishga asoslangan yo'nalish qaysi biri?",
    v: ["Radiojurnalistika", "Telejurnalistika", "Fotojurnalistika", "Raqamli jurnalistika"],
    t: 2,
    i: "Fotojurnalistika — voqealarni surat orqali hujjatlashtiradi."
  },
  {
    s: "Jurnalistik materiallarni ovoz, nutq va tovush vositalari orqali tinglovchilarga yetkazuvchi yo'nalish qanday atalanadi?",
    v: ["Fotojurnalistika", "Radiojurnalistika", "Telejurnalistika", "Surishtiruv jurnalistikasi"],
    t: 1,
    i: "Radiojurnalistika — materiallarni ovoz va nutq orqali yetkazadi."
  },
  {
    s: "Axborotni tasvir, ovoz, suhbat va lavha vositalari orqali tomoshabinlarga yetkazuvchi yo'nalish qaysi biri?",
    v: ["Telejurnalistika", "Radiojurnalistika", "Fotojurnalistika", "Raqamli jurnalistika"],
    t: 0,
    i: "Telejurnalistika — ekran vositalari orqali tomoshabinga yetkazadi."
  },
  {
    s: "Axborotni internet va raqamli texnologiyalar yordamida yig'ish va tarqatishga asoslangan yo'nalish qanday atalanadi?",
    v: ["Radiojurnalistika", "Telejurnalistika", "Fotojurnalistika", "Raqamli jurnalistika"],
    t: 3,
    i: "Raqamli jurnalistika — internet va raqamli texnologiyalarga asoslanadi."
  }
];
